import torch
from torch import nn
import numpy as np
from torch.utils.data import Dataset

from Calculate_Observation_Action import calculate_ost


# 2.规范训练数据由于预训练
class TrainDataset_pretrain(Dataset):
    def __init__(self, var):
        super(TrainDataset_pretrain, self).__init__()
        self.data_require, self.data_vtw, self.data_nw, self.data_mo, self.norm_require, self.norm_vtw, self.profit_rate = var
        self.size = self.data_require.size(0)  # 样本个数

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        # (static, dynamic, start_loc)
        return self.data_require[idx], self.data_vtw[idx], self.data_nw[idx], self.data_mo[idx], \
               self.norm_require[idx], self.norm_vtw[idx], self.profit_rate[idx]


# 稳定版嵌入层
class Embedding(nn.Module):
    def __init__(self, dim_in1, dim_in2, dim_out):
        super(Embedding, self).__init__()
        self.emb_conv1d1 = nn.Conv1d(dim_in1, dim_out, kernel_size=1)   # 输入（batch, channel, seq）
        self.emb_lstm = nn.LSTM(dim_out, dim_out, batch_first=True)     # 输入(batch, seq, feature)
        self.emb_conv1d2 = nn.Conv1d(dim_in2, dim_out, kernel_size=1)   # 输入出（batch, channel, seq）
        self.emb_conv1d3 = nn.Conv1d(2 * dim_out, dim_out, kernel_size=1)  # 输入出（batch, channel, seq）
        # self.dropout = nn.Dropout(dp)

    def forward(self, xw, xr, xnw):
        """

        :param xw: tensor, (batch_size,tar_num,max_nw,feature=11),归一化后的窗口数据
        :param xr: tensor, (batch_size,tar_num,feature=2), 归一化后的需求数据
        :param xnw: tensor, (batch,tar_num), 实际的窗口数量
        :return: out: tensor, （batch, tar_num, feature=128）, 输出嵌入层结果
        """
        bs, sl = xnw.size()
        # 1. 窗口数据嵌入
        emb_bw = []
        for bi in range(bs):
            emb_tw = []
            for ti in range(sl):
                vtw = xw[bi, ti, : xnw[bi, ti], :].T.unsqueeze(0)     # 实际的有效数据, (1，特征数1,窗口数)
                emb_w = self.emb_conv1d1(vtw).transpose(1, 2)       # (1,窗口数，特征数2)
                _, (_, h_t) = self.emb_lstm(emb_w)      # h_t隐藏层最终输出，(batch=1,seq=1, hidden)
                emb_tw.append(h_t[0, :, :])
            emb_bw.append(torch.cat(emb_tw))   # 拼接， (任务数，hidden)
        bw = torch.stack(emb_bw, 0)     # 拼接， (batch, seq, hidden)

        br = self.emb_conv1d2(xr.transpose(1, 2)).transpose(1, 2)   # (batch, seq, hidden)
        out = torch.cat((bw, br), 2)    # (batch, seq, 2*hidden)
        out = self.emb_conv1d3(out.transpose(1, 2)).transpose(1, 2)
        # out = self.dropout(out)
        return out      # batch, seq, feature


def sequence_scheduler(index, vtw, require, nw, sat_args):
    # 输入全转换为非tensor类型
    # 0任务编号，1卫星编号，2轨道编号，3窗口编号，4开始时间，5结束时间，
    # 6最大俯仰角，7最小俯仰角，8斜率k，9截距b，10滚动角
    reo = sat_args.eco_rate
    ret = sat_args.ect_rate
    rm = sat_args.mc_rate

    max_v = 6
    a = 2
    ST = 1

    bs, sl = nw.shape
    scheduling_results = np.zeros([bs, sl, 8])
    # 0选择的任务，1是否成功，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7收益
    results_evaluation = np.zeros([bs, 6])  # 6个指标
    # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
    results_evaluation[:, 0] = sl
    results_evaluation[:, 3] = require[:, :, 4].sum(1)
    for bi in range(bs):
        state = [1, 0, 0, 0, 0, sat_args.memory, sat_args.energy]
        # 0所在轨道（初始为1，表示初始轨道），1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量

        for si in range(sl):
            ti = index[bi][si]
            scheduling_results[bi, si, 0] = ti
            act0 = state[1:5]  # 0开始时间，1结束时间，2俯仰角，3侧摆角,只用于计算动作
            for wi in range(nw[bi, ti]):
                # 0先判断能否生成动作
                is_done, act1 = calculate_ost(act0, vtw[bi, ti, wi, 4:], require[bi, ti, 0])
                # 备注calculate_ost(oa0, vtw_info, d):
                # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
                #                               0   1  2  3
                # vtw_info：窗口信息: 最早开始时间，最晚开始时间，最大俯仰角，最小俯仰角，k，b，滚动角
                #                       0               1           2               3    4  5    6
                # d：表示任务持续时间 # b_require[bi, task_id, 0]持续时间
                #  b_vtw:4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
                if not is_done:     # 不能执行成功就下一个窗口
                    continue
                # 判断能量和存储约束能否满足
                if vtw[bi, ti, wi, 2] == state[0]:
                    rest_memory = state[5]
                    rest_energy = state[6]
                else:
                    rest_memory = sat_args.memory
                    rest_energy = sat_args.energy
                # 1存储约束
                con_memory = require[bi, ti, 2] * rm  # 观测的存储消耗
                if con_memory > rest_memory:  # 所需大于剩余
                    # 如果刚进入一个新轨道，那么这两个条件必然是满足的
                    continue  # 不满足条件就判断下一个窗口
                # 2能量约束
                con_energy_o = require[bi, ti, 2] * reo  # 观测所需的能量
                trans_a = abs(act1[2] - act0[2]) + abs(act1[3] - act0[3])   # 转换的角度
                con_energy_t = trans_a * ret  # 转换动作的能量消耗
                if con_energy_t + con_energy_o > rest_energy:
                    continue  # 不满足条件就判断下一个窗口
                # 至此一个任务的窗口满足了所有约束
                # 更新规划结果和卫星状态
                scheduling_results[bi, si, 1] = 1
                scheduling_results[bi, si, 2] = vtw[bi, ti, wi, 2]  # 轨道
                scheduling_results[bi, si, 3:7] = act1
                scheduling_results[bi, si, 7] = require[bi, ti, 4]
                # 更新卫星状态
                state[0] = vtw[bi, ti, wi, 2]  # 轨道
                state[1:5] = act1
                state[5] = rest_memory - con_memory
                state[6] = rest_energy - con_energy_t - con_energy_o
                break   # 至此完成了一个任务的规划，跳出循环
                # 如果没有执行成功，规划结果只需存一个任务索引，其他全0，状态也不需要更新
    # 更新评价指标
    results_evaluation[:, 1] = scheduling_results[:, :, 1].sum(1)
    results_evaluation[:, 2] = results_evaluation[:, 1] / sl
    results_evaluation[:, 4] = (scheduling_results[:, :, 7] * scheduling_results[:, :, 1]).sum(1)
    results_evaluation[:, 5] = results_evaluation[:, 4] / results_evaluation[:, 3]

    return scheduling_results, results_evaluation


# 3.单步调度器
# 3.3 调度器
# # 已知每个任务的概率，待规划任务及其窗口，窗口信息，需求信息， 窗口数量信息，卫星属性，下一步的掩码矩阵
def scheduler_step_new(task_pro, mask_vb, mask_ud, mask_n, current_state, b_vtw, b_require, b_nw, b_mo, sat_args,
                       o_list, t_key):
    """
    首先明确，都是batch数据
    :param task_pro: tensor batch,seq_len   动作的概率
    :param mask_vb: torch.bool: batch      表示还没完成的样本为True,已完成的为False
    :param current_state: tensor batch,6    当前的状态   # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    :param mask_n: tenor batch,seq_len    当前轨道上可选的任务及其窗口
    :param mask_ud: tenor batch,seq_len   待规划任务
    :param b_vtw: tenor batch,seq_len,max_nw,11  窗口信息
    :param b_require: tenor batch,seq_len,2     需求信息    持续时间，优先级
    :param b_nw: tenor batch,seq_len    任务的窗口数量 `#b_index: tensor batch,seq_len    任务排序索引,没用到
    :param b_mo: tensor batch,sl,max_oi, 2, 任务是否分布在该轨道和对应窗口
    :param sat_args: 卫星属性参数
    :param o_list: 列表，样本数*[tensor(轨道数)],有任务分布的轨道编号，所以不同样本也是不一样的
    :param t_key: tensor, 样本数*任务数*2个轨道*2个特征（实际所在轨道，任务编号），跨轨道任务的窗口所在轨道可能不是实际轨道
    :return: 单步规划结果，更新后的状态，跟新后的next矩阵，待规划矩阵
    """
    # b_require:torch数组是一个batch的数据
    # 样本数*任务数*特征数  0观测持续时间，1收益    # 成像质量需求已经用于初步处理时间窗了
    # b_vtw # 样本数*任务数*窗口数*特征数 0任务编号，1卫星编号，2轨道编号，3窗口编号，
    #     4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
    # b_nw: 窗口数量

    # 1.初始值
    bz, sl = task_pro.size()  # sl是任务数

    reo = sat_args.eco_rate
    ret = sat_args.ect_rate
    rm = sat_args.mc_rate

    # 2.初始化返回值
    next_state = torch.zeros([bz, 7])  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    scheduling_results = torch.zeros([bz, 8])
    # 0选择的动作即任务，1是否能执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7收益

    select_index = torch.zeros(bz, dtype=int) - 1  # 表示每个样本选择的索引，初始化为-1
    deleted_index = [[] for _ in range(bz)]     # 每个样本被舍弃的任务

    # 3.逐个样本实现单步规划
    # 测试概率出现nan值--------------------------------------------------------开始-----------------------------------
    # for bi in range(bz):
    #     if mask_vb[bi] & (torch.isnan(task_pro[bi,:])).any():
    #         print('样本未完成但概率有nan值', bi)
    # 测试概率出现nan值--------------------------------------------------------结束-----------------------------------
    for bi in range(bz):  # 逐个样本判断
        if not mask_vb[bi]:  # 假表示该样本已完成规划
            continue
        # st = time.time()
        # 状态 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        state0 = current_state[bi, 1:5]  # 0开始时间，1结束时间，2俯仰角，3侧摆角,只用于计算动作
        curr_tasks = torch.where(mask_n[bi, :] >= 0)[0]     # 当前待规划的任务索引

        # 3.1 选择概率最大的动作

        ni = task_pro[bi, :].argmax()  # ni 是next矩阵中的索引，动作索引，代表选择的任务

        # if task_pro[bi, ni] == 0:   # 测试用!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        #     print('3.1错误，被选任务的概率为0！')

        select_index[bi] = ni  # 选中的索引

        ws = []  # 可供选择的窗口
        # 有小概率这一个窗口在当前轨道上，下一个窗口在下一个轨道上
        flag_complete_task = False  # 该任务是否成功执行的标志符
        if mask_n[bi, ni] < 2:
            ws.append(t_key[bi, ni, mask_n[bi, ni], 1])
            w_count = mask_n[bi, ni] - 1
        else:
            w_count = -1
            for index in range(2):
                ws.append(t_key[bi, ni, index, 1])

        for wi in ws:  # wi必然是在当前两个轨道上的窗口
            # 3.1.1 判断可行性及生成观测动作
            # (1)先计算能否生成新动作，姿态转换时间是否满足
            # if b_vtw[bi, ni, wi, 4:].sum() == 0:  # !!!!!!!!!!!!!!!!!!!!!!!测试用，后删
            #     print('全是0', [bi, ni])
            is_done, state1 = calculate_ost(state0.tolist(), b_vtw[bi, ni, wi, 4:].tolist(), b_require[bi, ni, 2].tolist())
            # 备注calculate_ost(oa0, vtw_info, d):
            # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
            #                               0   1  2  3
            # vtw_info：窗口信息: 最早开始时间，最晚开始时间，最大俯仰角，最小俯仰角，k，b，滚动角
            #                       0               1           2               3    4  5    6
            # d：表示任务持续时间 # b_require[bi, task_id, 2]持续时间
            #  b_vtw:4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
            if not is_done:  # 该动作没有成功生成
                # print('1 动作无法生成')
                continue  # 不满足条件就判断下一个窗口
            state1 = torch.tensor(state1)

            # 分两大类进行讨论
            if b_vtw[bi, ni, wi, 2] == current_state[bi, 0]:     # 还在同一个轨道
                rest_memory = current_state[bi, 5]  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                rest_energy = current_state[bi, 6]
            else:   # 不在同一个轨道
                rest_memory = sat_args.memory
                rest_energy = sat_args.energy
            # 存储和能量约束判断
            # （2）计算观测所需的内存和能量,并判断观测内存可行性
            con_memory = b_require[bi, ni, 2] * rm
            con_energy_o = b_require[bi, ni, 2] * reo  # 观测所需的能量
            if con_memory > rest_memory:  # 所需大于剩余
                # 如果刚进入一个新轨道，那么这两个条件必然是满足的
                # print('2 存储不满足约束', con_memory, rest_memory)
                continue  # 不满足条件就判断下一个窗口

            # （3）继续判断动作转换是否满足能量约束
            con_energy_t = (abs(state0[2] - state1[2]) + abs(state0[3] - state1[3])) * ret  # 以度数来计算
            if con_energy_t + con_energy_o > rest_energy:
                # print('3 能量不满足约束', con_energy_t + con_energy_o, rest_energy)
                continue  # 不满足条件就判断下一个任务
            flag_complete_task = True
            w_count += 1    # flag_complete_task为真，w_count必然>0
            wi_selected = wi
            break
        # 至此完成了当前轨道上的一个任务规划
        # et2 = time.time()
        # print('2 选择一个任务完成规划用时：', et2 - et1)

        curr_tasks = curr_tasks[curr_tasks.ne(ni)]  # 删除被选中的任务后剩余当前待规划任务
        # 更新调度方案和执行完任务后的卫星状态、undone值
        if flag_complete_task:  # 表明该任务成功执行
            # if t_key[bi, ni, w_count, 0] == 0:    # 测试-------------------------------
            #     print('检索表中轨道编号为0')
            # 3.2  任务成功执行更新单步调度方案和对应矩阵mask_ud、mask_n、mask_nw
            # 3.2.1  单步调度方案，在不在当前轨道都一样
            current_oi = b_vtw[bi, ni, wi_selected, 2]  # 该窗口所在的轨道
            # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
            scheduling_results[bi, 0] = ni  # 任务编号
            scheduling_results[bi, 1] = 1  # 成功执行
            scheduling_results[bi, 2] = t_key[bi, ni, w_count, 0]   # 表示规划所在轨道，跨轨窗口其值可能不等于轨道编号
            scheduling_results[bi, 3: 7] = state1  # [st,et,pa,ra]
            scheduling_results[bi, 7] = b_require[bi, ni, 4]  # 收益

            # 3.2.2 执行完任务后的状态, 考虑到可能存在跨轨道任务
            # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            next_state[bi, 0] = state1[1] // sat_args.orbit_period + 1  # 轨道编号
            next_state[bi, 1:5] = state1
            if next_state[bi, 0] == current_oi:  # 保险一点的写法
                next_state[bi, 5] = rest_memory - con_memory
                next_state[bi, 6] = rest_energy - con_energy_t - con_energy_o
            else:
                next_state[bi, 5] = sat_args.memory
                next_state[bi, 6] = sat_args.energy
            # if next_state[bi, 5] == 0 or next_state[bi, 6] == 0:
            #     print('剩余存储或约束为0')
            # 3.2.3  更新当前任务的undone值
            mask_ud[bi, ni] = 1

            for dti in curr_tasks:  # 去掉选择的任务后的当前待规划的任务逐个判断
                if b_vtw[bi, dti, b_nw[bi, dti]-1, 5] < state1[1]:  # 直接判断最后一个窗口最晚开始时间是否早于动作结束时间
                    mask_ud[bi, dti] = -1  # 舍弃
                    deleted_index[bi].append(dti)  # 放弃的任务
            # et3 = time.time()
            # print('3 执行成功更新信息用时：', et3 - et2)
            # 测试是否删除干净了-----------------------------------------------------------------------------------
            # task_ud = torch.where(mask_ud[bi, :] == 0)[0]  # 找出未规划任务的索引
            # if min(task_ud.shape) != 0:  # 不空
            #     for cti in task_ud:
            #         if b_vtw[bi, cti, b_nw[bi, cti]-1, 5] < state1[1]:  # 最后一个窗口的最晚开始时间在当前轨道之前
            #             print('删除测试1：应该删除但是没有删除：', bi, cti, b_vtw[bi, cti, b_nw[bi, cti]-1, 5], state1[1])
            # # 测试是否多删除
            # for cti in deleted_index[bi]:
            #     if b_vtw[bi, cti, b_nw[bi, cti]-1, 5] >= state1[1]:  # 最后一个窗口的最晚开始时间在当前轨道之后
            #         print('删除测试2：不应该删除但是被删除了：', bi, cti, b_vtw[bi, cti, b_nw[bi, cti] - 1, 5], state1[1])
            # 测试--------------------------------------------结束-------------------------------------------------
            # et4 = time.time()
            # print('4 执行成功后删除信息判断用时：', et4 - et3)
        else:
            # 3.3 执行不成功, 更新单步调度方案、状态和对应矩阵mask_ud
            # 3.3.1 更新方案
            # current_oi = current_state[bi, 0]  # 还在当前轨道
            # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
            scheduling_results[bi, 0] = ni  # 任务编号
            scheduling_results[bi, 1] = 0  # 执行失败
            scheduling_results[bi, 2] = b_vtw[bi, ni, wi, 2]  # 该窗口所在的轨道
            scheduling_results[bi, 3: 7] = b_vtw[bi, ni, wi, 4:8]  # [st,et,maxpa,minpa]
            scheduling_results[bi, 7] = b_require[bi, ni, 4]  # 收益

            # 3.3.2 执行完任务后的状态
            # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            next_state[bi, :] = current_state[bi, :]  # 保持不变

            # 3.3.3  更新当前任务的undone值
            mask_ud[bi, ni] = -1  # 放弃
            # et3 = time.time()
            # print('3 执行失败更新信息用时：', et3 - et2)

        # 3.4 继续更新下一阶段的next和o_scheduled矩阵,next轨道next_state[bi, 0]
        # 先对当前next和nw值初始化
        current_oi = int(next_state[bi, 0])
        mask_n[bi, :] = -1   # 初始化 下阶段待规划的任务
        t_key[bi, :, :, :] = 0  # 初始化任务检索表
        task_ud = torch.where(mask_ud[bi, :] == 0)[0]  # 找出未规划任务的索引

        if min(task_ud.shape) != 0:  # 不空, 此时剩余轨道不可能没有
            count_o = 0  # 有任务的轨道数
            if current_oi > o_list[bi][0]:
                oi = current_oi - 1
                task_oi = torch.where(b_mo[bi, :, oi, 0])[0]  # 在该轨道上的任务
                if task_oi.numel() > 0:  # 该轨道上有任务
                    flag_ud = mask_ud[bi, task_oi] == 0  # 未规划的任务位置上为真
                    if flag_ud.any():  # 真表示该轨道上有任务未规划
                        # 未规划可能的原因：一是跨轨道任务，二是有窗口在后续的轨道上
                        task_ou = task_oi[flag_ud]  # 该轨道上未规划的任务索引
                        for ti in task_ou:  # 逐个任务判断
                            wi = b_mo[bi, ti, oi, 1]    # 窗口
                            if b_vtw[bi, ti, wi, 5] >= next_state[bi, 2]:
                                mask_n[bi, ti] = 0
                                t_key[bi, ti, 0, 0] = current_oi    # 窗口最晚开始时间所在轨道
                                t_key[bi, ti, 0, 1] = wi
                                count_o = 1

            task_oi = torch.where(b_mo[bi, :, current_oi, 0])[0]  # 在该轨道上的任务
            if task_oi.numel() > 0:  # 该轨道上有任务
                flag_ud = mask_ud[bi, task_oi] == 0  # 未规划的任务位置上为真
                if flag_ud.any():  # 真表示该轨道上有任务未规划
                    task_ou = task_oi[flag_ud]  # 该轨道上未规划的任务索引
                    mask_n[bi, task_ou] = 0     # 此处的任务与跨轨道的任务不可能重复
                    t_key[bi, task_ou, 0, 0] = current_oi
                    t_key[bi, task_ou, 0, 1] = b_mo[bi, task_ou, current_oi, 1]
                    count_o = 1

            rest_orbit = o_list[bi]
            rest_orbit = rest_orbit[rest_orbit.gt(current_oi)]  # 编号大于当前轨道的轨道
            # 因为任务的删除，剩余的轨道上有可能没有任务了
            for oi in rest_orbit:
                task_oi = torch.where(b_mo[bi, :, oi, 0])[0]   # 在该轨道上的任务
                # if task_oi.numel() == 0:    # 该轨道上没有任务，报错---------------测试-------------------------
                #     print(' 该轨道上没有任务，报错')
                #     continue
                flag_ud = mask_ud[bi, task_oi] == 0  # 未规划的任务位置上为真
                if flag_ud.any():   # 真表示有任务在该轨道上
                    task_ou = task_oi[flag_ud]  # 该轨道上未规划的任务索引
                    t_key[bi, task_ou, count_o, 0] = int(oi)
                    t_key[bi, task_ou, count_o, 1] = b_mo[bi, task_ou, oi, 1]
                    count_o += 1
                    mask_n[bi, task_ou] += count_o
                    # count_o=1时，表示在第一个轨道上，初始next值肯定是-1，结果是0
                    # count_o=2时，表示在第二个轨道上，初始next值是-1或0，结果是1或2
                    if count_o >= 2:    # 2个轨道上的任务next值更新完毕
                        break
            # 结束循环oi
        else:   # 没有带规划任务
            mask_vb[bi] = False  # 该样本规划结束
    return mask_vb, select_index, deleted_index, scheduling_results, next_state, mask_ud, mask_n, t_key


