import torch

# 3.1 单个方向的姿态转换时间的计算
def transition_time(delt_a, max_v, a, stability_time):
    """
    # stability_time = 1  # 稳定时间1秒
    # max_v = 3  # 最大角速度
    # a = 1  # 加速度为2 °/s^2
    """

    if delt_a == 0:
        return 0
    elif 0 < delt_a <= max_v**2/a:
        tran_t = 2 * pow(delt_a / a, 0.5) + stability_time  # 转换时间
    elif delt_a <= 90:  # 最大转换角度就是90度
        tran_t = delt_a / max_v + max_v / a + stability_time
    else:
        print('角度超出范围')
        return -1
    return tran_t


# 3.2 根据上一个状态和当前待规划任务的信息，计算当前任务的执行动作
# 二次不等式求解
def solve_quadratic_inequality(a, b, c):
    # 解一元二次不等式，可知曲线开口向上，求>=0的范围，所以必然是有解的
    # A>0
    drt = b ** 2 - 4 * a * c
    # is_existed = 1 # 存在解的个数
    outcome = []

    if drt <= 0:  # 表示恒成立
        is_existed = 1
    elif drt > 0:
        x1 = (-b - drt ** 0.5) / (2 * a)  # 小的解
        x2 = (-b + drt ** 0.5) / (2 * a)  # 大的解
        is_existed = 0
        outcome = [x1, x2]
    return is_existed, outcome


# 线性不等式求解
def solve_linear_inequality(a, b):
    # 解线性不等式
    # ax>b
    outcome = []
    if a == 0:  # 无解
        flag = -1
    elif a > 0:  # >outcome
        flag = 1
        outcome = b / a
    else:  # a<0，  <outcome
        flag = 0
        outcome = b / a
    return flag, outcome


# 计算执行动作
def calculate_ost(oa0, vtw_info, d):
    # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
    #                               0   1  2  3
    # vtw_info：窗口信息 最早开始时间，最晚开始时间，k，b，滚动角
    #                       0               1        2  3    4
    # d：表示任务持续时间
    # 输出 是否成功，下一个oa
    # 按照数据的特点，时间窗斜率k绝对值是小于1.5的，如果不是，就报错
    # 因为数据太多，所以用符号命名，防止混淆
    ST = 1  # 稳定时间3秒,一个方向1秒，2个方向就是2秒
    a = 1  # 角加速度
    omega = 3  # 最大角速度

    # if torch.is_tensor(oa0):
    #     oa0 = oa0.tolist()
    # if torch.is_tensor(vtw_info):
    #     vtw_info = vtw_info.tolist()
    # if torch.is_tensor(d):
    #     d = d.tolist()
    et0 = oa0[1]
    p0 = oa0[2]
    r0 = oa0[3]
    pl = -45
    pu = 45
    k = vtw_info[2]
    b = vtw_info[3]
    r = vtw_info[4]

    # ------------------------------------------------测试----------------------------------------------
    # if k == 0:
    #     print('错误：calculate_ost，存在时间窗斜率k等于0：', vtw_info)
    #     # 直接输出先前状态
    #     return False, oa0
    # elif k > 0:
    #     print('错误：calculate_ost，存在时间窗斜率k大于0：', vtw_info)
    # ------------------------------------------------测试结束----------------------------------------------
    # 要找最大俯仰角，对应最早开始时间
    # 依次求解4个方程
    delt_r = abs(r - r0)
    tran_r = transition_time(delt_r, omega, a, ST)
    if et0 + tran_r > vtw_info[1]:   # 滚动角调整后的时间已经超过了窗口最晚开始时间
        # -----------------------------------------测试开始-------------------------------------
        # if et0 > vtw_info[1]:
        #     print('0 窗口最晚开始时间<空闲开始时间')
        # else:
        #     print('0滚动转换时间太长,delt_r:{:f},tran_r:{:f}'.format(delt_r, tran_r))
        # -----------------------------------------测试结束-------------------------------------
        return False, oa0

    free_st = et0 + tran_r + ST      # 这种情况不考虑俯仰角不变化的时候，即p！=p0
    # ST是俯仰角稳定所需要的角度
    if free_st > vtw_info[0]:
        pamax = b + k * free_st
    else:
        pamax = pu
    pamin = pl
    p_threshold = omega**2 / a  # 计算出阈值
    # 根据p可能的值从大到小计算
    p1 = p0 + p_threshold   # 中间值
    # 1 p>p1 => p-p0>p_threshold 加速-匀速-减速
    ps_valid = False    # 表示是否生成了有效俯仰角
    pa_range = [max(p1, pamin), pamax]
    if pa_range[0] <= pa_range[1]:
        xa = 1 / k - 1 / omega  # 必然是负的
        xb = free_st - p0 / omega + omega / a + b / k
        temp_flag, px = solve_linear_inequality(xa, xb)
        if temp_flag == 1:  # >px   可行的p范围 [-, pa_range[1]]
            if px <= pa_range[1]:
                ps_valid = True
                ps = pa_range[1]   # 选择的俯仰角为ps
        elif temp_flag == 0:  # <px
            if px >= pa_range[0]:   # 可行的p范围 [pa_range[0], min(px, pa_range[1])]
                ps_valid = True
                ps = min(px, pa_range[1])
        else:  # xa=0
            if xb == 0:  # 恒成立
                ps_valid = True
                ps = pa_range[1]
        if ps_valid:
            st = (ps - b) / k
            # --------------------测试----------------------------------
            # tt = tran_r + transition_time(abs(ps - p0), omega, a, ST)
            # if et0 + tt > st + 0.001:
            #     print('错误1：转换时间超出范围')
            # --------------------测试结束----------------------------------
            return True, [st, st + d, ps, r]
    # 2. p0<p<p1=p0+p_threshold => 0<p-p0<p_threshold 加速-减速
    # 如果此处得到结果p=p0，那么必然是可以执行的
    pa_range = [max(p0, pamin), min(p1, pamax)]
    if pa_range[0] <= pa_range[1]:
        xa = 1 / k ** 2  # A>0
        xb = - 4 / a - 2 / k * (b / k + free_st)
        xc = (b / k + free_st) ** 2 + 4 / a * p0
        temp_flag, px_range = solve_quadratic_inequality(xa, xb, xc) #  开口向上的二次曲线
        if temp_flag:  # 表示恒成立,取最大值
            ps_valid = True
            ps = pa_range[1]
        else:  # 表示方程有两个解,先看大的解是否符合条件，再看小的
            if px_range[1] <= pa_range[1]:  # 值域[max(pa_range[0], px_range[1]) , pa_range[1]],取最大值
                ps_valid = True
                ps = pa_range[1]
            elif px_range[0] >= pa_range[0]:  # 值域[pa_range[0] , min(px_range[0], pa_range[1])]
                ps_valid = True
                ps = min(px_range[0], pa_range[1])
            # 两种情况都不满足，说明两个值域没有重叠，解集为空
        if ps_valid:
            st = (ps - b) / k
            # --------------------测试----------------------------------
            tt = tran_r + transition_time(abs(ps - p0), omega, a, ST)
            # if et0 + tt > st + 0.001:
            #     print('错误2：转换时间超出范围')
            # --------------------测试结束----------------------------------
            return True, [st, st + d, ps, r]
    # 3. p=p0
    st = (p0 - b) / k
    if et0 + tran_r <= st:  # 俯仰角不变就没有稳定时间
        return True, [st, st + d, p0, r]
    # 4. p0-p_threshold=p2<p<p0 => 0<p0-p<p_threshold 加速-减速
    p2 = p0 - p_threshold
    pa_range = [max(p2, pamin), min(p0, pamax)]
    if pa_range[0] <= pa_range[1]:
        xa = 1 / k ** 2  # A>0
        xb = 4 / a - 2 / k * (b / k + free_st)
        xc = (b / k + free_st) ** 2 - 4 / a * p0
        temp_flag, px_range = solve_quadratic_inequality(xa, xb, xc)
        # 开口向上的二次曲线, 取值范围为 <= px_range[0] 或 >= px_range[1]
        if temp_flag:  # 表示恒成立,取最大值
            ps_valid = True
            ps = pa_range[1]
        else:  # 表示方程有两个解,先看大的解是否符合条件，再看小的
            if px_range[1] <= pa_range[1]:  # >=px_range[1]  取最大值 值域[max(pa_range[1], px_range[0]), pa_range[1]]
                ps_valid = True
                ps = pa_range[1]
            elif px_range[0] >= pa_range[0]:    # <=px_range[0] 值域[pa_range[0], min(px_range[0],pa_range[1])]
                ps_valid = True
                ps = min(px_range[0], pa_range[1])
            # 两种情况都不满足，说明两个值域没有重叠，解集为空
        if ps_valid:
            st = (ps - b) / k
            # --------------------测试----------------------------------
            # tt = tran_r + transition_time(abs(ps - p0), omega, a, ST)
            # if et0 + tt > st + 0.001:
            #     print('错误4：转换时间超出范围')
            # --------------------测试结束----------------------------------
            return True, [st, st + d, ps, r]
    # 5. p<p0-p_threshold=p2 => p0-p>p_threshold   加速-匀速-减速
    pa_range = [pamin, min(p2, pamax)]
    if pa_range[0] <= pa_range[1]:
        xa = 1 / k + 1 / omega  # k≈-0.3 Omega=3，所以xa不可能等于0
        xb = free_st + p0 / omega + omega / a + b / k
        temp_flag, px = solve_linear_inequality(xa, xb)
        if temp_flag == 1:  # >px
            if px <= pa_range[1]:  # [max(px,pa_range[0]) , pa_range[1]]
                ps_valid = True
                ps = pa_range[1]
        elif temp_flag == 0:  # <px
            if px >= pa_range[0]:  # [pa_range[0], min(px,pa_range[1])]
                ps_valid = True
                ps = min(px, pa_range[1])
        else:  # xa=0
            if xb == 0:  # 恒成立
                ps_valid = True
                ps = pa_range[1]
        if ps_valid:
            st = (ps - b) / k
            # --------------------测试----------------------------------
            # tt = tran_r + transition_time(abs(ps - p0), omega, a, ST)
            # if et0 + tt > st + 0.001:
            #     print('错误5：转换时间超出范围')
            # --------------------测试结束----------------------------------
            return True, [st, st + d, ps, r]
    return False, oa0


# 计算最早可行时间，用于LSTM——SAC_v1 2024-01-10
def earliest_observation_time(vtw, k, b, act_state, max_v, a, ST):
    '''

    :param vtw: est,lst,ra
    :param act_state:ft,pa,ra
    :param max_v:
    :param a:
    :param st:
    :return:
    '''
    if k>=0:
        raise ValueError('Error-earliest_observation_time: k is not less than 0!')
    pu = 45
    pl = -45
    tran_rt = transition_time(abs(vtw[2]-act_state[2]), max_v, a, ST)

    op_list = []

    # 1 op=pa
    if k*act_state[1]+b-act_state[0]>=tran_rt:  # 满足转换时间约束
        op_list.append(act_state[1])
    p_threshold = max_v ** 2 / a

    delt_T = b - act_state[0] - tran_rt - ST
    # 2 pa-max_v^2/a<=op<pa    解一元二次方程is_existed, outcome = solve_quadratic_inequality(a, b, c):
    opmax = -delt_T/k
    op_range = [max(pl, act_state[1]-p_threshold), min(act_state[1], opmax)]    # 确定角度范围
    if op_range[0] <= op_range[1]:
        flag, outcome = solve_quadratic_inequality(k**2, 2*k*delt_T+4/a, delt_T**2-4/a*act_state[1])
        if flag:    # 曲线开口向上，>=0. 为1表示恒成立，取最大值
            op_list.append(op_range[1])
        else:   # 为0表示<=小值，>=大值
            if op_range[1] <= outcome[0] or op_range[1] >= outcome[1]:
                op_list.append(op_range[1])
            else:  # outcome[0] <= op_range[1] <= outcome[1]
                if op_range[0] <= outcome[0]:
                    op_list.append(outcome[0])
    # 3 pa<op<=pa+max_v^2/a
    op_range = [act_state[1], min(pu, act_state[1] + p_threshold, opmax)]  # 确定角度范围
    if op_range[0] <= op_range[1]:
        flag, outcome = solve_quadratic_inequality(k ** 2, 2 * k * delt_T - 4 / a, delt_T ** 2 + 4 / a * act_state[1])
        if flag:    # 曲线开口向上，>=0. 为1表示恒成立，取最大值
            op_list.append(op_range[1])
        else:   # 为0表示<=小值，>=大值
            if op_range[1] <= outcome[0] or op_range[1] >= outcome[1]:
                op_list.append(op_range[1])
            else:  # outcome[0] <= op_range[1] <= outcome[1]
                if op_range[0] <= outcome[0]:
                    op_list.append(outcome[0])
    # 4 op<=pa-max_v^2/a,解线性不等式ax>b solve_linear_inequality(a, b):
    op_range = [pl, min(pu, act_state[1] - p_threshold)]
    if op_range[0] <= op_range[1]:
        flag, outcome = solve_linear_inequality(k+1/max_v, act_state[1]/max_v+max_v/a-delt_T)
        if flag==1:     # >OUTCOME
            if outcome <= op_range[1]:
                op_list.append(op_range[1])
        elif flag==0:   # <outcome
            if op_range[0]<=outcome<=op_range[1]:
                op_list.append(outcome)
            elif outcome>op_range[1]:
                op_list.append(op_range[1])
    # 5 op>=pa+max_v^2/a,
    op_range = [max(pl, act_state[1] + p_threshold), pu]
    if op_range[0] <= op_range[1]:
        flag, outcome = solve_linear_inequality(k - 1 / max_v, -act_state[1] / max_v + max_v / a - delt_T)
        if flag == 1:  # >OUTCOME
            if outcome <= op_range[1]:
                op_list.append(op_range[1])
        elif flag == 0:  # <outcome
            if op_range[0] <= outcome <= op_range[1]:
                op_list.append(outcome)
            elif outcome > op_range[1]:
                op_list.append(op_range[1])

    if len(op_list)==0:
        return False, None
    else:
        return True, max(op_list)




