# 用于定时，由PN-SD实现任务分配，确定各个任务分配到哪个轨道上，
# 然后逐个轨道利用SAC算法逐个任务的确定执行时间
# 这是定时网络的构建和训练代码

# 编写时间：2023-12-25
# 修改时间：2024-1-10  对动作做了些修改，提升解的质量
# 修改时间：2024-1-11  修改了奖励
# 修改时间：2024-1-12  进一步修改task_profit结果不太对的问题
# 作者：LZ
import random

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.utils.tensorboard import SummaryWriter
from torch.distributions import Normal
from copy import deepcopy
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import time

from variable_length_sequence import CustomRNN  # 处理可变长的序列
from Calculate_Observation_Action import transition_time, earliest_observation_time


class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim, max_action):  # dp, , dropout=dp
        super(Actor, self).__init__()
        self.max_action = max_action

        self.state_lstm = CustomRNN(state_dim, hidden_dim, batch_first=True)
        self.mean_layer = nn.Linear(hidden_dim, action_dim)
        self.log_std_layer = nn.Linear(hidden_dim, action_dim)

    def forward(self, x, len, deterministic=False, with_logprob=True):
        _, (x, _) = self.state_lstm(x, len)
        x = x.squeeze(0)
        mean = self.mean_layer(x)
        log_std = self.log_std_layer(x)  # We output the log_std to ensure that std=exp(log_std)>0
        log_std = torch.clamp(log_std, -20, 2)
        std = torch.exp(log_std)

        dist = Normal(mean, std)  # Generate a Gaussian distribution
        if deterministic:  # When evaluating，we use the deterministic policy
            a = mean
        else:
            a = dist.rsample()  # reparameterization trick: mean+std*N(0,1)

        if with_logprob:  # The method refers to Open AI Spinning up, which is more stable.
            log_pi = dist.log_prob(a).sum(dim=1, keepdim=True)
            log_pi -= (2 * (np.log(2) - a - F.softplus(-2 * a))).sum(dim=1, keepdim=True)
        else:
            log_pi = None

        a = self.max_action * torch.tanh(a)
        # Use tanh to compress the unbounded Gaussian distribution into a bounded action interval.

        return a, log_pi


class Critic(nn.Module):  # According to (s,a), directly calculate Q(s,a)
    def __init__(self, state_dim, action_dim, hidden_dim):  # , dp, dropout=dp, dropout=dp
        super(Critic, self).__init__()
        # Q1
        self.state_lstm1 = CustomRNN(state_dim, hidden_dim, batch_first=True)
        self.action_linear1 = nn.Linear(action_dim, hidden_dim)
        self.l1 = nn.Linear(hidden_dim * 2, hidden_dim)
        self.l2 = nn.Linear(hidden_dim, 1)
        # Q2
        self.state_lstm2 = CustomRNN(state_dim, hidden_dim, batch_first=True)
        self.action_linear2 = nn.Linear(action_dim, hidden_dim)
        self.l3 = nn.Linear(hidden_dim * 2, hidden_dim)
        self.l4 = nn.Linear(hidden_dim, 1)

    def forward(self, s, len, a):
        _, (s1, _) = self.state_lstm1(s, len)
        s1 = s1.squeeze(0)
        a1 = self.action_linear1(a)
        sa1 = torch.cat([s1, a1], 1)
        q1 = F.relu(self.l1(sa1))
        q1 = self.l2(q1)

        _, (s2, _) = self.state_lstm2(s, len)
        s2 = s2.squeeze(0)
        a2 = self.action_linear2(a)
        sa2 = torch.cat([s2, a2], 1)
        q2 = F.relu(self.l3(sa2))
        q2 = self.l4(q2)

        return q1, q2


class ReplayBuffer(object):
    def __init__(self, state_dim, action_dim, max_size=int(1e5), min_size=int(1e4)):
        self.state_dim = state_dim
        self.max_size = max_size
        self.min_size = min_size
        self.count = 0
        self.size = 0
        self.length = torch.zeros((self.max_size, 1), dtype=torch.int)  # 序列的长度
        self.s = [[] for _ in range(self.max_size)]
        self.a = torch.zeros((self.max_size, action_dim), dtype=torch.float)
        self.r = torch.zeros((self.max_size, 1), dtype=torch.float)
        self.s_ = [[] for _ in range(self.max_size)]
        self.dw = torch.zeros((self.max_size, 1), dtype=torch.float)

    def store(self, l, s, a, r, s_, dw):
        self.length[self.count] = deepcopy(l)
        self.s[self.count] = deepcopy(s)
        self.a[self.count] = deepcopy(a)
        self.r[self.count] = deepcopy(r)
        self.s_[self.count] = deepcopy(s_)
        self.dw[self.count] = deepcopy(dw)
        self.count = (self.count + 1) % self.max_size  # When the 'count' reaches max_size, it will be reset to 0.
        self.size = min(self.size + 1, self.max_size)  # Record the number of  transitions

    def sample(self, batch_size):
        index = np.random.choice(self.size, size=batch_size)  # Randomly sampling
        batch_length = deepcopy(self.length[index])[:,0]
        batch_s = torch.zeros([batch_size, batch_length.max(), self.state_dim], dtype=torch.float)
        batch_s_ = torch.zeros([batch_size, batch_length.max(), self.state_dim], dtype=torch.float)
        for si in range(batch_size):
            i = index[si]
            batch_s[si, :self.length[i], :] = deepcopy(self.s[i])   # [:self.length[i], :]
            batch_s_[si, :self.length[i], :] = deepcopy(self.s_[i]) # [:self.length[i], :]

        batch_a = deepcopy(self.a[index])
        batch_r = deepcopy(self.r[index])
        batch_dw = deepcopy(self.dw[index])

        return batch_length, batch_s, batch_a, batch_r, batch_s_, batch_dw

def input_standard(state, sat_arg):
    # state_tensor归一化处理
    state_norm = torch.zeros(state.size())  # 构造状态 13维
    state_norm[:, :, 1] = torch.true_divide(state[:, :, 1], sat_arg.orbit_times)  # 轨道
    state_norm[:, :, 2] = torch.true_divide(state[:, :, 2], sat_arg.period)  # est
    state_norm[:, :, 3] = torch.true_divide(state[:, :, 3], sat_arg.period)  # lst
    state_norm[:, :, 4] = torch.true_divide(state[:, :, 4] - sat_arg.min_roll,
                                            sat_arg.max_roll - sat_arg.min_roll)  # ra
    state_norm[:, :, 5] = torch.true_divide(state[:, :, 5], 10)  # duration
    state_norm[:, :, 6] = torch.true_divide(state[:, :, 6], 10)  # profit
    state_norm[:, :, 7] = torch.true_divide(state[:, :, 7], sat_arg.period)  # ost
    state_norm[:, :, 8] = torch.true_divide(state[:, :, 8], sat_arg.period)  # oet
    state_norm[:, :, 9] = torch.true_divide(state[:, :, 9] - sat_arg.min_pitch,
                                            sat_arg.max_pitch - sat_arg.min_pitch)  # opa
    state_norm[:, :, 10] = torch.true_divide(state[:, :, 10] - sat_arg.min_roll,
                                             sat_arg.max_roll - sat_arg.min_roll)  # ora
    state_norm[:, :, 11] = torch.true_divide(state[:, :, 11], sat_arg.memory)  # rm
    state_norm[:, :, 12] = torch.true_divide(state[:, :, 12], sat_arg.energy)  # re
    return state_norm


class SAC(object):
    def __init__(self, state_dim, action_dim, hidden_dim, max_action, batch_size=128, gamma=0.99, lr=0.001):
        self.max_action = max_action
        self.hidden_width = hidden_dim  # The number of neurons in hidden layers of the neural network
        self.batch_size = batch_size  # batch size=128
        self.GAMMA = gamma  # discount factor gamma=0.99
        self.TAU = 0.005  # Softly update the target network
        self.lr = lr  # learning rate 0.001
        self.adaptive_alpha = True  # Whether to automatically learn the temperature alpha
        if self.adaptive_alpha:
            # Target Entropy = −dim(A) (e.g. , -6 for HalfCheetah-v2) as given in the paper
            self.target_entropy = -action_dim
            # We learn log_alpha instead of alpha to ensure that alpha=exp(log_alpha)>0
            self.log_alpha = torch.zeros(1, requires_grad=True)
            self.alpha = self.log_alpha.exp()
            self.alpha_optimizer = torch.optim.Adam([self.log_alpha], lr=self.lr)
        else:
            self.alpha = 0.2

        self.actor = Actor(state_dim, action_dim, hidden_dim, max_action)
        self.critic = Critic(state_dim, action_dim, hidden_dim)
        self.critic_target = deepcopy(self.critic)

        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=self.lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=self.lr)

    def finish_training(self):
        return self.actor.state_dict(), self.critic.state_dict(), self.critic_target.state_dict()

    def load(self, actor_state, critic_state, critic_target_state):
        self.actor.load_state_dict(actor_state)
        self.critic.load_state_dict(critic_state)
        self.critic_target.load_state_dict(critic_target_state)

    def choose_action(self, s, len, deterministic=False):
        # s = torch.unsqueeze(torch.tensor(s, dtype=torch.float), 0)
        a, _ = self.actor(s, len, deterministic, False)  # When choosing actions, we do not need to compute log_pi
        return a.data.numpy().flatten()

    def learn(self, relay_buffer, sat_arg):
        batch_l, batch_s, batch_a, batch_r, batch_s_, batch_dw = relay_buffer.sample(self.batch_size)  # Sample a batch
        # batch_length, batch_s, batch_a, batch_r, batch_s_, batch_dw
        # 需要归一化处理
        norm_s = input_standard(batch_s, sat_arg)
        norm_s_ = input_standard(batch_s_, sat_arg)

        with torch.no_grad():
            batch_a_, log_pi_ = self.actor(norm_s_, batch_l)  # a' from the current policy
            batch_a_ = batch_a_.squeeze(0)
            # Compute target Q
            target_Q1, target_Q2 = self.critic_target(norm_s_, batch_l, batch_a_)
            target_Q = batch_r + self.GAMMA * (1 - batch_dw) * (torch.min(target_Q1, target_Q2) - self.alpha * log_pi_)

        # Compute current Q
        current_Q1, current_Q2 = self.critic(norm_s, batch_l, batch_a)
        # Compute critic loss
        critic_loss = F.mse_loss(current_Q1, target_Q) + F.mse_loss(current_Q2, target_Q)
        # Optimize the critic
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # Freeze critic networks so you don't waste computational effort
        for params in self.critic.parameters():
            params.requires_grad = False

        # Compute actor loss
        a, log_pi = self.actor(norm_s, batch_l)
        Q1, Q2 = self.critic(norm_s, batch_l, a)
        Q = torch.min(Q1, Q2)
        actor_loss = (self.alpha * log_pi - Q).mean()

        # Optimize the actor
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # Unfreeze critic networks
        for params in self.critic.parameters():
            params.requires_grad = True

        # Update alpha
        if self.adaptive_alpha:
            # We learn log_alpha instead of alpha to ensure that alpha=exp(log_alpha)>0
            alpha_loss = -(self.log_alpha.exp() * (log_pi + self.target_entropy).detach()).mean()
            self.alpha_optimizer.zero_grad()
            alpha_loss.backward()
            self.alpha_optimizer.step()
            self.alpha = self.log_alpha.exp()

        # Softly update target networks
        for param, target_param in zip(self.critic.parameters(), self.critic_target.parameters()):
            target_param.data.copy_(self.TAU * param.data + (1 - self.TAU) * target_param.data)

        return actor_loss, critic_loss, alpha_loss


def observation_action(vtw, duration, sat_state, action, sat_arg):
    '''
    只处理一个样本

    :param vtw: array, [0开始时间，1结束时间，2滚动角]
    :param sat_state: 0fst空闲开始时间,1pa,2ra,3rm,4re
    :param action: float
    :param sat_arg:
    :return:
    '''

    sat_action = np.zeros(6)  # 开始时间,结束时间,pa,ra,rm,re
    # 1.先判断内存容量是否满足约束
    con_m = sat_arg.mc_rate * duration
    if con_m > sat_state[3]:  # 消耗存储大于剩余
        return False, sat_action

    # 2.计算观测动作是否满足约束
    if action < 0:
        action = - action

    # 计算当前角度对应的观测开始时间# st = k1*pa+b1,k1=(est-lst)/(max_pa-min_pa),b=(est+lst)/2
    # b=est-(est-lst)/(max_pa-min_pa)*max_pa,因为max_pa+min_pa=0,所以b可以直接转换为(est+lst)/2
    pk = (vtw[0] - vtw[1]) / (sat_arg.max_pitch - sat_arg.min_pitch)
    pb = (vtw[0] + vtw[1]) / 2
    ora = vtw[2]
    opa = action * sat_arg.max_pitch  # 俯仰角
    # 计算转换时间,并判断是否满足转换时间约束
    # transition_time(delt_a, max_v=3, a=1, stability_time=1)
    # ST = 1  # 稳定时间3秒,一个方向1秒，2个方向就是2秒
    # a = 1  # 角加速度
    # omega = 3  # 最大角速度
    tranT = transition_time(abs(opa - sat_state[1]), max_v=3, a=1, stability_time=1) + \
            transition_time(abs(ora - sat_state[2]), max_v=3, a=1, stability_time=1)
    # 计算当前角度对应的观测开始时间# st = k1*pa+b1,k1=(est-lst)/(max_pa-min_pa),b=(est+lst)/2
    ost = pk * opa + pb
    if sat_state[0] + tranT > ost:  # 不满足约束
        # 计算满足约束的最早观测时间对应的最大俯仰角
        # flag, pa = earliest_observation_time(vtw, k, b, act_state, max_v, a, ST):
        flag_early, opa = earliest_observation_time(vtw, pk, pb, sat_state[:3], max_v=3, a=1, ST=1)
        if not flag_early:
            return False, sat_action
        ost = pk * opa + pb  # 观测开始时间
    # 至此,观测动作能够满足 内存容量约束\转换时间约束


    # 3.判断能量消耗是否满足约束
    con_eo = sat_arg.eco_rate * duration
    con_et = sat_arg.ect_rate * (abs(ora - sat_state[2]) + abs(opa - sat_state[1]))
    con_e = con_eo + con_et
    if con_e > sat_state[4]:
        return False, sat_action
    # 计算观测动作
    sat_action[0] = ost
    sat_action[1] = ost + duration
    sat_action[2] = opa
    sat_action[3] = ora
    sat_action[4] = sat_state[3] - con_m
    sat_action[5] = sat_state[4] - con_e
    return True, sat_action


def decompose(task_sequence, complete_num, task_vtw, task_require, matrix_orbit):
    '''

    :param task_sequence: (bs,sl,6)# 0 任务编号，1所在轨道，2开始时间，3结束时间，4俯仰角，5滚动角,6收益
    :param complete_num: (bs,) int array
    :param task_vtw: (bs,sl,nwx,9) [0任务编号，1卫星编号，2轨道编号，3窗口编号，4开始时间，5结束时间，6斜率k，7截距b，8滚动角]
    :param task_require:(bs,sl,4) 0纬度，1经度，2观测持续时间，3收益
    :param matrix_orbit: (bs,sl,2) 0是否在该轨道,1窗口编号
    :return:
        decomposed_task_sequence bs*[orbit_num*[array(ot_num, x)]]
        # 8维   0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
    '''

    # 批处理
    bs, sl, _, _ = task_vtw.shape
    decomposed_task_sequence = [[] for _ in range(bs)]
    decomposed_task_length = [[] for _ in range(bs)]
    batch_orbit_num = np.zeros(bs).astype(int)
    for bi in range(bs):
        single_sequence = task_sequence[bi, : complete_num[bi], :]  # 实际的有效可执行序列
        orbits = np.unique(single_sequence[:, 1]).astype(int)  # 有任务的轨道
        orbit_num = len(orbits)  # 有任务的轨道数量
        batch_orbit_num[bi] = orbit_num
        decomposed_task_sequence[bi] = [[] for _ in range(orbit_num)]
        decomposed_task_length[bi] = np.zeros(orbit_num, dtype=int)
        count_oi = 0
        for oi in orbits:
            ot_list = np.where(single_sequence[:, 1] == oi)[0]  # 在该轨道上的任务索引
            ot_num = len(ot_list)
            decomposed_task_length[bi][count_oi] = ot_num  # 该轨道上的任务数也是序列长度
            ot_seq = np.zeros([ot_num, 8])
            # 8维   0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
            ot_seq[:, 0] = single_sequence[ot_list, 0]  # 任务编号
            ot_seq[:, 2] = oi  # 轨道编号
            ot_seq[:, 7] = single_sequence[ot_list, 6]  # 收益
            count_oti = 0
            for oti in ot_list:  # 这是任务索引,不是任务编号
                ti = int(single_sequence[oti, 0])  # 任务编号
                if matrix_orbit[bi, ti, oi, 0] == 0:
                    # 可能是结束时间在下一个轨道
                    if matrix_orbit[bi, ti, oi - 1, 0] == 0:
                        raise ValueError('Error-decompose: task has no VTWs inn the orbit', [bi, ti, oi])
                    else:
                        wi = matrix_orbit[bi, ti, oi - 1, 1]
                else:
                    wi = matrix_orbit[bi, ti, oi, 1]
                ot_seq[count_oti, 1] = wi  # 窗口编号
                ot_seq[count_oti, 3] = task_vtw[bi, ti, wi, 4]
                ot_seq[count_oti, 4] = task_vtw[bi, ti, wi, 5]
                ot_seq[count_oti, 5] = task_vtw[bi, ti, wi, 8]
                ot_seq[count_oti, 6] = task_require[bi, ti, 2]
                # ot_seq[count_oti, 7] = task_require[bi, ti, 3]
                count_oti += 1
            decomposed_task_sequence[bi][count_oi] = deepcopy(ot_seq)
            count_oi += 1
        # 一个样本的分解已经完成,并构建了输入数据
    # 一个batch的数据分解处理完成
    return decomposed_task_sequence, decomposed_task_length, batch_orbit_num


def batch_generate(decomposed_task_sequence, decomposed_task_length, batch_orbit_num):
    ''' 原代码逐个处理然后存入,此处对数据处理形成batch数据
    生成批处理的np数组,用0补齐
    :param decomposed_task_sequence: list[bs*list[orbit_num*list[array(ot_num*8)]]]
        0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
    :param decomposed_task_length: list[bs*list[array(orbit_num,)]]
    :return:
    '''
    bs = len(decomposed_task_sequence)
    max_orbit_num = np.max(batch_orbit_num)
    batch_dt_seq = [[] for _ in range(max_orbit_num)]
    # batch_dt_len = [[] for _ in range(max_orbit_num)]
    batch_ot_num = np.zeros([max_orbit_num, bs]).astype(int)  # 每个轨道上每个样本的任务的数量

    for count_oi in range(max_orbit_num):
        for bi in range(bs):
            if count_oi < len(decomposed_task_length[bi]):  # 该样本在第count_oi轨道上任务
                batch_ot_num[count_oi, bi] = decomposed_task_length[bi][count_oi]
                # 否则就为0,不需要赋值
        max_ot_num = np.max(batch_ot_num[count_oi, :])  # 最大任务数
        batch_dt_seq[count_oi] = np.zeros([bs, max_ot_num, 8])  # 8个信息
        for bi in range(bs):
            if batch_ot_num[count_oi, bi] > 0:  # 等于0表示该样本在该轨道上没有任务
                batch_dt_seq[count_oi][bi, :batch_ot_num[count_oi, bi], :] = deepcopy(
                    decomposed_task_sequence[bi][count_oi])

    return batch_dt_seq, batch_ot_num


# 规范训练数据由于训练
class TimingTrainDataset(Dataset):
    def __init__(self, so_seq, so_seq_len):
        super(TimingTrainDataset, self).__init__()
        self.seq = so_seq
        self.seq_len = so_seq_len
        self.size = len(so_seq)  # 样本个数

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        # (static, dynamic, start_loc)
        return self.seq[idx], self.seq_len[idx]


def evaluate_policy(replay_buff, sat_arg, agent, batch_size):
    # orbit_task_seq:0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
    # 1 在经验池中随机取样
    batch_l, batch_s, batch_a, batch_r, batch_s_, batch_dw = replay_buff.sample(batch_size)  # Sample a batch
    # batch_length, batch_s, batch_a, batch_r, batch_s_, batch_dw
    batch_state = deepcopy(batch_s)
    # 0状态，1轨道，2est，3lst，4ra，5d，6p，7ost，8oet，9opa，10ora，11rm，12re
    batch_state[:, :, 0] = 0
    batch_state[:, 1:, 7:] = 0
    dw_tensor = batch_l == 0  # 有的样本在该轨道上没有任务，即为真，有任务初始为假
    if dw_tensor.any():  # 真表示有样本在该轨道上没有任务
        raise ValueError('Error-evaluate_policy 1: 所有样本都没有任务')
    batch_quality = np.zeros([batch_size, batch_s.size(1)-1])

    # batch_a, _ = agent(batch_s, batch_l)  # a' from the current policy
    # batch_a = batch_a.squeeze(0)
    while not dw_tensor.all():  # 全真才表示整个样本都规划完了
        # 4.3.1 生成动作
        # state_tensor归一化处理
        norm_state = input_standard(batch_state, sat_arg)
        # （1） 由网络生成动作
        action = agent.choose_action(norm_state, batch_l, deterministic=True)  # (-1,1)区间内的一个数值
        # 生成动作，计算观测动作 batch_opa = action * SatArgs.max_pitch
        bi_tensor = torch.where(~dw_tensor)[0]  # 未完成规划的样本，dw_tensor真表示该样本规划完成了
        for bi in bi_tensor:
            # 4.3.2 根据动作确定观测动作，更新环境状态
            # batch_dt_seq 0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
            t_index = torch.where(batch_state[bi, :, 0] == 0)[0][1]    # 未规划的任务索引
            orti = t_index - 1
            flag_success, oa = observation_action(batch_state[bi, t_index, 2:5], batch_state[bi, t_index, 5],
                                                  batch_state[bi, t_index-1, 8:], action[bi], sat_arg)
            # observation_action(vtw, duration, sat_state, action, sat_arg)
            #     :param vtw: array, [0开始时间，1结束时间，2滚动角]
            #     :param sat_state: 0fst空闲开始时间,1pa,2ra,3rm,4re
            #   return flag, oa(0开始时间,1结束时间,2pa,3ra,4rm,5re)
            # sat_action: 0st,1et,2pa,3ra,4rm,5re

            # 4.3.3 根据动作确定观测动作，更新环境状态，计算奖励
            if flag_success:  # 规划成功
                batch_state[bi, t_index, 0] = 1
                batch_state[bi, t_index, 7:] = deepcopy(torch.tensor(oa))
                #  state_tensor 0状态，1轨道，2est，3lst，4ra，5d，6p，7ost，8oet，9opa，10ora，11rm，12re
                iq = 1 - 0.9 * abs(oa[2]) / SatArgs.max_pitch  # 成像质量即奖励
                r = iq*batch_state[bi, t_index, 6].tolist() # 奖励
            else:  # 没有成功规划，卫星状态不变，更新环境状态
                batch_state[bi, t_index, 0] = -1
                batch_state[bi, t_index, 7:] = deepcopy(batch_state[bi, t_index - 1, 7:])
                r = 0
            # 判断是否完成了该样本在该轨道上的调度
            if t_index == batch_l[bi] - 1:  # 表示该索引对应该轨道最后一个任务
                dw_tensor[bi] = True

            # 把调度结果存入orbit_result :8状态，9ost，10oet，11opa，12ora，13rm，14re，15成像质量
            batch_quality[bi, orti] = r
    # 至此，该轨道上一个batch的样本规划完成,对应调度结果也已保存
    # 计算调度指标
    mean_qpr = np.zeros(batch_size)
    for bi in range(batch_size):
        mean_qpr[bi] = batch_quality[bi, :].sum()/batch_state[bi, 1:, 6].sum().item()
    return mean_qpr.mean()


if __name__ == '__main__':
    import os
    import datetime
    import argparse
    import math

    # main 1: 载入数据，明确保存路径
    # 1.1 载入数据
    filepath0 = os.path.dirname(os.getcwd())  # 获取文件夹上一级的文件夹路径
    task_num = 100
    load_path = filepath0 + '\Result\TrainingDatasetResults\FCFS_RD_All\RD_' + str(task_num) + '.pt'
    batch_require, batch_vtw, batch_nw, batch_mo, batch_norm_require, batch_norm_vtw, \
    Results, Results_eval = torch.load(load_path)
    Results = Results[:1280, :, :]
    Results_eval = Results_eval[:1280, :]
    np_require, np_vtw, np_nw, np_mo = batch_require[:1280, :, :].numpy(), batch_vtw[:1280, :, :,:].numpy(), \
                                       batch_nw[:1280, :].numpy(), batch_mo[:1280, :, :,:].numpy()

    # 1.2 保存路径
    algorithm_name = 'LSTM_SAC_v3'
    time_str = '%s' % datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')
    now = time_str.replace('.', '')
    now = now.replace(' ', '_')
    now = now.replace(':', '')
    # path = filepath0 + '\\Result\\Training_Result\\RD_All\\' + algorithm_name + '_' + now
    path = filepath0 + '\\Result\\Timing_Training_Result\\RD_' + str(task_num) + '\\' + algorithm_name + '_' + now
    os.makedirs(path)
    fp = open(filepath0 + '\\Result\\Timing_Training_Result\\Training Log.txt', 'a', encoding='utf-8')
    fp.write('\n' + time_str + ' ' + algorithm_name + ' 训练结果保存路径：' + path)
    fp.close()
    print('\n训练结果保存路径：', path)
    path_writer = path + '\\log'
    writer = SummaryWriter(path_writer)

    # main 2: 参数设置
    # 2.1 卫星参数
    sat_parser = argparse.ArgumentParser(description='Parameters of AOS')
    sat_parser.add_argument('--orbit_times', default=14.20176543000019, type=float, help='24h内轨道圈次')
    sat_parser.add_argument('--orbit_period', default=24 * 60 * 60 / 14.20176543000019, type=float, help='平均轨道周期')
    sat_parser.add_argument('--energy', default=1500, type=float)
    sat_parser.add_argument('--memory', default=1000, type=float)
    sat_parser.add_argument('--eco_rate', default=1, type=float)  # 观测时能量消耗速率 *时间
    sat_parser.add_argument('--ect_rate', default=0.5, type=float)  # 姿态转换时能量消耗速率 *度数
    sat_parser.add_argument('--mc_rate', default=1, type=float)  # 内存消耗速率    *时间
    sat_parser.add_argument('--max_pitch', default=45, type=float)  # 俯仰角
    sat_parser.add_argument('--min_pitch', default=-45, type=float)  # 俯仰角
    sat_parser.add_argument('--max_roll', default=45, type=float)  # 滚动角
    sat_parser.add_argument('--min_roll', default=-45, type=float)  # 滚动角
    sat_parser.add_argument('--period', default=60 * 60 * 24, type=float)  # 调度周期
    SatArgs = sat_parser.parse_args()
    # 2.2 网络模型参数
    model_parser = argparse.ArgumentParser(description='Parameters of NetModel')
    model_parser.add_argument('--dim_state', default=13, type=int, help='状态维度')
    model_parser.add_argument('--dim_action', default=1, type=int, help='需求数据维度')
    model_parser.add_argument('--dim_hidden', default=128, type=int, help='隐藏层维度')
    # model_parser.add_argument('--drop_out', default=0.1, type=float, help='神经元停止概率')
    model_parser.add_argument('--max_action', default=1, type=float, help='动作的最大值')
    ModelArgs = model_parser.parse_args()
    # 2.3 训练参数
    train_parser = argparse.ArgumentParser(description='Parameters of training')
    train_parser.add_argument('--batch_size', default=64, type=int, help='批大小')
    # train_parser.add_argument('--min_size', default=1e4, type=int, help='批大小')
    train_parser.add_argument('--epochs', default=30, type=int, help='完整训练的轮次')
    train_parser.add_argument('--learning_rate', default=0.001, type=float, help='主网络学习率')
    train_parser.add_argument('--max_grad_norm', default=5., type=float, help='网络参数梯度的范数上限')
    TrainArgs = train_parser.parse_args()

    # main 3: 分解策略，把可执行序列分成多个轨道上的数据，并且规范输入输出格式 构造batch数据
    decomposed_seq, decomposed_len, batch_orbit_num = decompose(Results, Results_eval[:, 1].astype(int), np_vtw,
                                                                np_require, np_mo)
    # decompose(task_sequence, complete_num, task_vtw, task_require, matrix_orbit)
    # 注意输入的task_sequence为:
    # (bs,sl,6)# 0 任务编号，1所在轨道，2开始时间，3结束时间，4俯仰角，5滚动角,6收益

    decomposed_task_seq, orbit_task_num = batch_generate(decomposed_seq, decomposed_len, batch_orbit_num)
    orbit_num = len(decomposed_task_seq)
    train_data = [[] for _ in range(orbit_num)]
    train_iter = [[] for _ in range(orbit_num)]
    for i in range(orbit_num):  # 0 是数据， 1是任务数
        train_data[i] = TimingTrainDataset(decomposed_task_seq[i], orbit_task_num[i, :])

    batch_num = Results.shape[0] // TrainArgs.batch_size  # 迭代次数，也是batch的总数
    # 当前生成的数据是在所有数据上处理的,所以bs=2560
    # main 3: 构建网络
    agent = SAC(ModelArgs.dim_state, ModelArgs.dim_action, ModelArgs.dim_hidden, ModelArgs.max_action,
                batch_size=TrainArgs.batch_size, lr=TrainArgs.learning_rate)
    # state_dim, action_dim, hidden_dim, max_action, batch_size=128, gamma=0.99, lr=0.001)
    replay_buffer = ReplayBuffer(ModelArgs.dim_state, ModelArgs.dim_action)  # 初始化经验池

    # main 4:开始训练
    results = np.zeros([TrainArgs.epochs, batch_num, TrainArgs.batch_size, task_num, 16])  # 16维信息
    results_eval = np.zeros([TrainArgs.epochs, batch_num, TrainArgs.batch_size, 9])  # 9维
    # 0输入总任务数，1完成任务数，2完成率，3任务总收益，4输入任务的总收益，5完成任务的总收益，6收益率，
    # 7完成任务的成像质量，8成像质量率
    Losses = [[], [], []]
    Quality_profit = []
    Rewards=[[[] for i in range(batch_num)] for j in range(TrainArgs.epochs)]
    episode_steps = 0
    learning_steps = 0
    evaluate_freq = 10
    evaluate_num = 0
    decision_times = 0
    start_time = time.time()
    start_time1 = time.time()
    for epoch in range(TrainArgs.epochs):
        for oi in range(orbit_num):
            train_iter[oi] = iter(DataLoader(train_data[oi], TrainArgs.batch_size, shuffle=False, drop_last=True))  # 不打乱样本顺序
            # DataLoader 会把数据转换为tensor类型
        for batch_id in range(batch_num):  # 逐个batch
            # 4.1 卫星初始状态
            sat_action = torch.zeros([TrainArgs.batch_size, 6])  # 0st,1et,2pa,3ra,4rm,5re
            batch_results = [[] for _ in range(orbit_num)]
            if epoch == 0:  # 第一轮可以根据概率生成
                prob=0.5
            else:
                prob=0
            for oi in range(orbit_num):  # 逐个轨道
                # 4.2 状态、单轨调度结果的初始化
                batch_dt_seq, batch_ot_num = next(train_iter[oi])
                # batch_dt_seq:0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
                # batch_ot_num:轨道上各样本的任务数
                dw_tensor = batch_ot_num == 0  # 有的样本在该轨道上没有任务，即为真，有任务初始为假
                if dw_tensor.all(): # 全真表示该样本在该轨道上没有任务
                    continue
                # 进入新轨道内存和能量更新
                sat_action[:, 4] = SatArgs.memory
                sat_action[:, 5] = SatArgs.energy
                # sat_action_start = deepcopy(sat_action)
                batch_seq_len = batch_ot_num + 1  # 序列长度，有效的轨道上都是有任务的，不存在任务数为0的轨道
                state_tensor = torch.zeros([batch_dt_seq.size(0), batch_seq_len.max(), 13])  # 构造状态 13维
                # 0状态，1轨道，2est，3lst，4ra，5d，6p，7ost，8oet，9opa，10ora，11rm，12re
                state_tensor[:, 0, 7:] = deepcopy(sat_action)
                state_tensor[:, 1:, 1:7] = deepcopy(batch_dt_seq[:, :batch_ot_num.max(), 2:])

                # torch.zeros(TrainArgs.batch_size, dtype=torch.bool)  # 初始为假

                # image_quality = torch.zeros([TrainArgs.batch_size, batch_dt_seq.size(1)])   # 成像质量
                # orbit_results = torch.zeros([TrainArgs.batch_size, batch_dt_seq.size(1), 10])  # 单轨调度结果
                # # 0任务编号，1窗口编号，2状态，3轨道编号，4ost，5oet，6opa，7ora，8p，9or成像质量
                # orbit_results[:, :, :2] = deepcopy(batch_dt_seq[:, :, :2])  # 部分赋值

                # batch_dt_seq:0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p||
                # + 8状态，9ost，10oet，11opa，12ora，13rm，14re，15成像质量
                orbit_result = np.zeros([TrainArgs.batch_size, batch_dt_seq.size(1), 16])  # 单轨调度结果
                orbit_result[:, :, :8] = deepcopy(batch_dt_seq.numpy())

                # 4.3 正式开始解码确定动作，并存入结果
                # is_done = False  # 标识符，该batch中是否全部完成
                while not dw_tensor.all():  # 全真才表示整个样本都规划完了
                    # 随机决策或根据网络决策
                    # 随机生成动作，前一般是余弦衰减的概率，后一半是网络发挥作用
                    # 4.3.1 生成动作
                    # state_tensor归一化处理
                    state_norm = input_standard(state_tensor, SatArgs)
                    # （1） 由网络生成动作
                    action = agent.choose_action(state_norm, batch_seq_len)  # (-1,1)区间内的一个数值
                    # 生成动作，计算观测动作 batch_opa = action * SatArgs.max_pitch
                    bi_tensor = torch.where(~dw_tensor)[0]  # 未完成规划的样本，dw_tensor真表示该样本规划完成了
                    temp_reward = 0
                    for bi in bi_tensor:
                        # 先根据state_tensor找出未规划任务索引
                        # （2）根据概率生成随机动作
                        if random.random() < prob:
                            action[bi] = torch.rand(1)
                        # 4.3.2 根据动作确定观测动作，更新环境状态
                        # if t_index.numel() == 1:
                        #     raise ValueError('Error-main 4.3: no unscheduled tasks exist, but action is still generated!')
                        # batch_dt_seq 0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p
                        t_index = torch.where(state_tensor[bi, :, 0] == 0)[0][1]
                        orti = t_index - 1
                        flag_success, oa = observation_action(batch_dt_seq[bi, orti, 3:6],
                                                              batch_dt_seq[bi, orti, 6],
                                                              sat_action[bi, 1:], action[bi], SatArgs)
                        # observation_action(vtw, duration, sat_state, action, sat_arg)
                        #     :param vtw: array, [0开始时间，1结束时间，2滚动角]
                        #     :param sat_state: 0fst空闲开始时间,1pa,2ra,3rm,4re
                        #   return flag, oa(0开始时间,1结束时间,2pa,3ra,4rm,5re)
                        # sat_action: 0st,1et,2pa,3ra,4rm,5re

                        # 4.3.3 根据动作确定观测动作，更新卫星状态及环境状态，计算奖励
                        state_ = deepcopy(state_tensor[bi, :batch_seq_len[bi], :])
                        if flag_success:  # 规划成功
                            sat_action[bi, :] = deepcopy(torch.tensor(oa))
                            #  state_tensor 0状态，1轨道，2est，3lst，4ra，5d，6p，7ost，8oet，9opa，10ora，11rm，12re
                            state_[t_index, 0] = 1
                            state_[t_index, 7:] = deepcopy(torch.tensor(oa))
                            iq = 1 - 0.9 * abs(oa[2]) / SatArgs.max_pitch  # 成像质量
                            r = iq * state_tensor[bi, t_index, 6]          # 奖励
                        else:  # 没有成功规划，卫星状态不变，更新环境状态
                            state_[t_index, 0] = -1
                            state_[t_index, 7:] = deepcopy(sat_action[bi, :])
                            r = 0
                        # 判断是否完成了该样本在该轨道上的调度
                        if t_index == batch_ot_num[bi]:  # 表示该索引对应该轨道最后一个任务
                            dw_tensor[bi] = True
                        # 存入经验池 store(self, l, s, a, r, s_, dw)
                        replay_buffer.store(batch_seq_len[bi], state_tensor[bi, :batch_seq_len[bi], :], torch.tensor(action[bi]), r,
                                            state_, dw_tensor[bi])
                        state_tensor[bi, :batch_seq_len[bi], :] = deepcopy(state_)  # 更新状态，进入下一轮循环

                        # 把调度结果存入orbit_result :8状态，9ost，10oet，11opa，12ora，13rm，14re，15成像质量
                        orbit_result[bi, orti, 8] = deepcopy(state_[t_index, 0].numpy())
                        orbit_result[bi, orti, 9: 15] = deepcopy(state_[t_index, 7:].numpy())
                        orbit_result[bi, orti, 15] = r
                        temp_reward += r
                    temp_reward = temp_reward/len(bi_tensor)
                    Rewards[epoch][batch_id].append(temp_reward)
                    writer.add_scalar('agent\\rewards', temp_reward, decision_times)
                    decision_times += 1
                # 至此，该轨道上一个batch的样本规划完成并存入经验池,对应调度结果也已保存
                # 下面整理该轨道上，batch处理的结果
                # # batch_dt_seq:0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p||
                # # + 8状态，9ost，10oet，11opa，12ora，13rm，14re，15成像质量
                # orbit_result = np.zeros(TrainArgs.batch_size, batch_dt_seq.size(1), 15)
                batch_results[oi] = deepcopy(orbit_result)
                # 4.4 判断是否开始学习,训练并保存训练结果
                if replay_buffer.size >= replay_buffer.min_size:  # 达到就开始训练
                    actor_loss, critic_loss, alpha_loss = agent.learn(replay_buffer, SatArgs)
                    writer.add_scalars('agent\\losses', {'actor_loss': actor_loss, 'critic_loss': critic_loss, 'alpha_loss': alpha_loss},
                                       learning_steps)
                    Losses[0].append(actor_loss)
                    Losses[1].append(critic_loss)
                    Losses[2].append(alpha_loss)
                    learning_steps += 1

                    if learning_steps % evaluate_freq == 0:  # 每学习evaluate_freq次，评估一次策略的效果
                        # evaluate_policy(orbit_task_seq, orbit_task_num, sat_act, sat_arg, agent)
                        mean_qpr = evaluate_policy(replay_buffer, SatArgs, agent, TrainArgs.batch_size)
                        writer.add_scalar('agent\\evaluted_quality_profit', mean_qpr, evaluate_num)
                        Quality_profit.append(mean_qpr)
                        evaluate_num += 1

            # 至此完成了该batch中所有样本的规划

            # 4.5 整理完整的规划结果
            # batch_dt_seq:0任务编号，1窗口编号, 2轨道，3est，4lst，5ra，6d，7p||
            # + 8状态，9ost，10oet，11opa，12ora，13rm，14re，15成像质量
            for bi in range(TrainArgs.batch_size):  # 逐个样本
                rti = 0  # 在Results中的任务索引
                for oi in range(orbit_num):  # 逐个轨道
                    if len(batch_results[oi])==0:   # 列表为空，整个batch在该轨道上没有任务
                        continue
                    sample_state = batch_results[oi][bi, :, :]

                    for sti in range(sample_state.shape[0]):  # 任务数
                        if (sample_state[sti, :] == 0).all():  # 全真，表示不是有效任务
                            break
                        results[epoch, batch_id, bi, rti, :] = deepcopy(sample_state[sti, :])
                        rti += 1
                # 计算# 0输入总任务数，1完成任务数，2完成率，3总任务收益，4输入任务的总收益，5完成任务的总收益，6收益率，
                #     # 7考虑成像质量的完成任务的总收益，8考虑成像质量的任务收益率
                flag_completed = results[epoch, batch_id, bi, :, 8] == 1
                results_eval[epoch, batch_id, bi, 0] = rti  # 输入任务数
                results_eval[epoch, batch_id, bi, 1] = flag_completed.sum()  # 完成任务数
                if rti<flag_completed.sum():
                    print('输入任务数<完成任务数')
                results_eval[epoch, batch_id, bi, 2] = results_eval[epoch, batch_id, bi, 1] / task_num  # 真实的任务完成率
                results_eval[epoch, batch_id, bi, 3] = Results_eval[batch_id * TrainArgs.batch_size + bi, 3]  # 总任务收益
                results_eval[epoch, batch_id, bi, 4] = Results_eval[batch_id * TrainArgs.batch_size + bi, 4]  # 输入任务的总收益
                results_eval[epoch, batch_id, bi, 5] = (flag_completed * results[epoch, batch_id, bi, :, 7]).sum()
                # 完成任务的总收益
                results_eval[epoch, batch_id, bi, 6] = results_eval[epoch, batch_id, bi, 5] / \
                                                       results_eval[epoch, batch_id, bi, 3]
                results_eval[epoch, batch_id, bi, 7] = results[epoch, batch_id, bi, :,15].sum()  # 考虑成像质量的完成任务的总收益
                results_eval[epoch, batch_id, bi, 8] = results_eval[epoch, batch_id, bi, 7] / \
                                                       results_eval[epoch, batch_id, bi, 4]  # 考虑成像质量的任务收益率
                if results_eval[epoch, batch_id, bi, 8]>1:
                    print('考虑成像质量的收益率>1')
            # 至此，一个batch的样本的规划结果和指标都计算汇总完
            # 4.6 保存结果并显示
            writer.add_scalars('result\\task_number', {'input_number': results_eval[epoch, batch_id, :, 0].mean(), \
                                                       'completed_number': results_eval[epoch, batch_id, :, 1].mean()},
                               episode_steps)
            if results_eval[epoch, batch_id, :, 0].mean() < results_eval[epoch, batch_id, :, 1].mean():
                print('平均输入任务数<平均完成任务数')
            writer.add_scalars('result\\task_profit', {'input_profit': results_eval[epoch, batch_id, :, 4].mean(), \
                                                       'completed_profit': results_eval[epoch, batch_id, :, 5].mean()},
                               episode_steps)
            if results_eval[epoch, batch_id, :, 4].mean()<results_eval[epoch, batch_id, :, 5].mean():
                print('平均输入收益<平均完成任务收益')
            writer.add_scalar('result\\ImageQuality_ProfitRatio', results_eval[epoch, batch_id, :, 8].mean(), episode_steps)
            if results_eval[epoch, batch_id, :, 8].mean()>1:
                print('平均考虑成像质量的收益率>1')
            episode_steps += 1
        # 至此完成了所有样本数据的一轮迭代
        end_time1 = time.time()
        print('epoch:', epoch, ' 用时：', end_time1-start_time1)
        start_time1 = end_time1
    end_time = time.time()
    use_time = end_time - start_time
    print('用时：', use_time)
    model_path = path + '\\StateDict_' + algorithm_name + '_RD_' + str(task_num) + '_' + now + '.pt'
    actor_dict, critic_dict, critic_target_dict = agent.finish_training()
    torch.save([actor_dict, critic_dict, critic_target_dict], model_path)  # 保存网络参数
    variable_path = path + '\\Results_' + algorithm_name + '_RD_' + str(task_num) + '_' + now + '.pt'
    torch.save((Losses, Quality_profit, results, results_eval, use_time), variable_path)
    a_test = torch.load(variable_path)

    model_save = path + '\\Model_' + algorithm_name + '_RD_' + str(task_num) + '_' + now + '.pt'
    torch.save(agent, model_save)
