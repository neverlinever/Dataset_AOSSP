# PN-SD的神经网络模型构建和训练
# 编写时间：2023-12-26
# 修改时间：
# 作者：LZ
# 在任务数为100的问题上训练
# 这是最终的版本

import math
import numpy as np
import torch
import argparse
import torch.optim as optim
from torch import nn
import torch.nn.functional as F
from torch.nn import Parameter
from torch.utils.tensorboard import SummaryWriter

from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import time
import datetime
import os

from AttentionModel import Attention
from ProblemModel import scheduler_ls_od
# from Trainer import trend_mean, Adaptive_CosAnneal_WarmRestart
from SequencingNetworkModel import TrainDataset


# 1.静态嵌入层
# 静态嵌入包括两部分，窗口数据和需求数据
class Embedding(nn.Module):
    def __init__(self, dim_in1, dim_in2, dim_half, dp):
        super(Embedding, self).__init__()
        self.dim_half = dim_half
        # self.emb_conv1d1 = nn.Conv1d(dim_in1, dim_half, kernel_size=1)   # 输入（batch, channel, seq）
        self.emb_lstm = nn.LSTM(dim_in1, dim_half, batch_first=True)     # 输入(batch, seq, feature), dropout=dp
        self.emb_conv1d2 = nn.Conv1d(dim_in2, dim_half, kernel_size=1)   # 输入出（batch, channel, seq）
        self.emb_conv1d3 = nn.Conv1d(dim_half * 2, dim_half * 2, kernel_size=1)   # 输入出（batch, channel, seq）
        self.layer_norm = nn.LayerNorm(dim_half * 2)
        self.dropout = nn.Dropout(dp)

    def forward(self, xw, xr, xnw):
        """

        :param xw: tensor, (batch_size,tar_num,max_nw,feature=4),归一化后的窗口数据
        :param xr: tensor, (batch_size,tar_num,feature=2), 归一化后的需求数据
        :param xnw: tensor, (batch,tar_num), 实际的窗口数量
        :return: out: tensor, （batch, tar_num, feature=128）, 输出嵌入层结果
        """
        bs, sl = xnw.size()
        # 1. 窗口数据嵌入
        bw = torch.zeros([bs, sl, self.dim_half])
        for bi in range(bs):
            max_nw = xnw[bi, :].max()
            for nw in range(1, max_nw+1):
                t_indexes = torch.where(xnw[bi, :] == nw)[0]
                mbw = xw[bi, t_indexes, :nw, :]  # (mini batch, num vtw, feature)
                # emb_mbw = F.relu(self.emb_conv1d1(mbw.transpose(1, 2)).transpose(1, 2))
                # 卷积的输入与输出都是（batch, feature,seq）,所以都转换了，输出为(mini batch, num vtw, feature)
                _, (h_t, _) = self.emb_lstm(mbw)  # h_t隐藏层最终输出，(mini batch,seq=nw, hidden)
                bw[bi, t_indexes, :] = h_t.squeeze()

        br = F.relu(self.emb_conv1d2(xr.transpose(1, 2)).transpose(1, 2))   # (batch, seq, hidden)
        bwr = self.emb_conv1d3(torch.cat((bw, br), 2).transpose(1, 2)).transpose(1, 2)   # (batch, seq, hidden)
        out = self.dropout(self.layer_norm(bwr))   # (batch, seq, hidden)
        return out      # batch, seq, feature


## 2. 静态编码器Encoder 部分包含：多头注意力层及后续的前馈神经网络
class Encoder(nn.Module):
    def __init__(self, din, dout):  #, dp
        super(Encoder, self).__init__()
        self.lstm = nn.LSTM(din, dout, batch_first=True)    # , dropout=dp
        # self.dropout = nn.Dropout(dp)

    def forward(self, enc_in):
        out, hc = self.lstm(enc_in)
        return out, hc


class Decoder(nn.Module):
    def __init__(self, enc_dim, state_dim=6, dp=0.1):
        """

        :param enc_dim: 编码器输出维度
        :param state_dim: 隐藏层维度
        """
        super(Decoder, self).__init__()

        self.dropout = nn.Dropout(dp)
        self.enc_dim = enc_dim
        self.hidden_dim = enc_dim
        # 动态信息嵌、编码，然后与静态信息整合
        self.state_embedding = nn.Linear(state_dim, enc_dim)

        # 利用结合的信息计算概率
        self.lstm_cell = nn.LSTMCell(enc_dim * 2, enc_dim)  # (batch, input_size)
        self.att = Attention(enc_dim, enc_dim)
        self.layer_norm = nn.LayerNorm(enc_dim * 2)

    def forward(self, enc_out, hc, problem_info, so_num):
        """

        :param hc:
        :param enc_out: # batch,seq,feature
        :param problem_info: 包括卫星属性，窗口信息，需求信息，窗口数信息
        :param so_num:  int, 规划的轨道数量
        :return:
        """
        # Decoder step1: 参数的初始化
        # 1.1 变量的初始化
        sat_args, vtw_info, require_info, vtw_num, matrix_orbit = problem_info
        # matrix_orbit torch，（样本数，任务数，轨道数，2）# [表示任务是否在该轨道上，在的话是哪一个窗口]
        bs, sl, mnw, _ = vtw_info.size()  # 序列长度即任务数
        h_t, c_t = hc
        h_t = h_t.squeeze()
        c_t = c_t.squeeze()

        # 1.2 中间值的初始化
        mask_undone = torch.zeros([bs, sl], dtype=int)
        # 全0，表示未规划的任务，放弃用-1表示和已规划用1表示# 矩阵的索引就表示可选的任务索引
        mask_samples = torch.ones(bs).bool()  # 还需要规划的样本是true,其余False #  初始化全真
        state = torch.tensor([1, 0, 0, 0, 0, sat_args.memory, sat_args.energy]).repeat(bs, 1)  # 初始状态
        # 0所在轨道（初始为1，表示初始轨道），1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        seq_input = enc_out.new_zeros(torch.Size((bs, self.enc_dim)))  # new_zeros会复制数据类型和所在设备等
        self.att.init_inf(mask_undone.size())

        # 需要找出有任务的轨道
        orbits = vtw_info[:, :, :, 2].reshape(bs, -1).int()  # 表示batch中 每个任务所有窗口所在的轨道编号(bs,sl*max_nw)
        # ，轨道编号从1开始，0不是轨道编号
        orbits_list = [[] for _ in range(bs)]
        orbit_current_index = torch.zeros(bs, dtype=int)  # 当前调度的轨道在orbits_list中的索引
        for bi in range(bs):
            # 获取每个样本的有窗口的轨道编号
            temp_orbits = torch.unique(orbits[bi, :])   # 默认sorted=True, return_inverse=False, return_counts=False, dim=None
            # 返回值升序排列，不返回重复元素的索引和个数
            if temp_orbits[0] == 0:
                temp_orbits = temp_orbits[1:]
            orbits_list[bi] = temp_orbits   # 每个样本中有任务的轨道
        # 完成了orbits_list有窗口的轨道的序列

        # 1.3: 返回值初始化
        results = [[] for _ in range(bs)]   # 每个调度步的结果，结果有8个特征，索引0表示选择的动作
        # 0选择的动作[0,sl)，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7任务收益

        results_evaluation = torch.zeros([bs, 6])  # 6个指标
        # 评价指标：总任务数，完成任务数，任务完成率，总收益，完成收益，任务收益率
        results_evaluation[:, 0] = sl
        results_evaluation[:, 3] = torch.sum(require_info[:, :, 1], 1)
        results_prob = torch.zeros([bs, sl])    # 每个动作被选中时的概率

        # Decoder step2: 开始循环计算概率获取序列
        while torch.any(mask_samples):  # 有真为真
            # 2.1: 动态信息归一化后，嵌入、编码
            # state:# 0所在轨道（初始为0，表示初始状态），1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            # state_norm:# 0轨道编号，1空闲开始时间，2俯仰角，3侧摆角，4存储，5能量
            state_norm = torch.zeros(bs, 6)  # 归一化处理
            state_norm[:, 0] = torch.true_divide(state[:, 0], sat_args.orbit_times)
            state_norm[:, 1] = torch.true_divide(state[:, 2], sat_args.period)
            state_norm[:, 2] = torch.true_divide((state[:, 3] - sat_args.min_pitch),
                                                 (sat_args.max_pitch - sat_args.min_pitch))
            state_norm[:, 3] = torch.true_divide((state[:, 4] - sat_args.min_roll),
                                                 (sat_args.max_roll - sat_args.min_roll))
            state_norm[:, 4] = torch.true_divide(state[:, 5], sat_args.memory)
            state_norm[:, 5] = torch.true_divide(state[:, 6], sat_args.energy)
            # state_norm = state_norm.to(device)  # 0轨道编号，1空闲开始时间，2俯仰角，3侧摆角，4存储，5能量
            # 2.2 状态嵌入
            state_emb = F.relu(self.state_embedding(state_norm))
            # 静态数据和动态数据拼接后整合
            sd_input = self.dropout(self.layer_norm(torch.cat((seq_input, state_emb), 1)))  # batch, 2*hidden
            # 2.3:  动态解码,根据整合信息获取概率，由注意力机制计算概率分布，再通过局部选测策略获取下一步规划任务
            # 2.3.1：计算概率分布
            h_t, c_t = self.lstm_cell(sd_input, (h_t, c_t))
            if torch.isnan(h_t).any() or torch.isnan(c_t).any() or torch.isnan(sd_input).any():  #------测试-----------
                raise ValueError('Error-decoder: 2.2 exists NAN!')
            _, probability = self.att(h_t, enc_out, mask_undone.ne(0))  # 0表示未规划，把0值全部屏蔽
            # 2.3.1：单步调度
            # scheduling_results, next_state, select_index, deleted_index, mask_s, mask_ud, curr_orbit
            # = scheduler_ls_od(prob, son, curr_orbit, orbit_list, curr_state, mask_s, mask_ud,
            # b_vtw, b_require, b_nw, b_mo, sat_args)
            step_results, state, step_select, step_delete, mask_samples, mask_undone, orbit_current_index = \
                scheduler_ls_od(probability, so_num, orbit_current_index, orbits_list, state, mask_samples, \
                                mask_undone, vtw_info, require_info, vtw_num, matrix_orbit, sat_args)

            # 结果的汇总, 输入序列信息的更新, 更新策略矩阵
            seq_input = enc_out.new_zeros(seq_input.size())  # new_zeros会复制数据类型和所在设备等
            for bi in range(bs):
                results[bi].append(step_results[bi, :])
                if step_select[bi] != -1:
                    # 值为-1表示没有选中任何任务，当该样本早就结束才会这样
                    results_prob[bi, step_select[bi]] = probability[bi, step_select[bi]]
                    seq_input[bi, :] = enc_out[bi, step_select[bi], :]
                else:       # 判断，用于检测------------------------------！-------------------------
                    if mask_samples[bi]:
                        raise ValueError('Error-decoder: 2.3.1 no selected task, but scheduling has not been finished!')
                for ti in step_delete[bi]:
                    # 被放弃的任务的概率
                    results_prob[bi, ti] = probability[bi, ti]
                # 需要判断一下已经规划的任务是否都有概率
                for dti in step_delete[bi]:
                    if results_prob[bi, dti] == 0:
                        raise ValueError('Error-decoder: 2.3.1 the prob of the deleted task is zero!')
        # Decoder step3: 计算指标以及选中动作的概率
        results_torch = torch.zeros([bs, len(results[0]), 8])
        for bi in range(bs):

            results_torch[bi, :, :] = torch.cat(results[bi]).view(len(results[0]), -1)
            # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
            results_evaluation[bi, 1] = torch.sum(results_torch[bi, :, 1])  # 能执行的任务数
            results_evaluation[bi, 2] = results_evaluation[bi, 1]/results_evaluation[bi, 0]
            results_evaluation[bi, 4] = (results_torch[bi, :, 1] * results_torch[bi, :, 7]).sum()
            results_evaluation[bi, 5] = results_evaluation[bi, 4]/results_evaluation[bi, 3]

        # results_evaluation
        return results_torch, results_evaluation, results_prob      # , consume_time


class PointerNet_SD(nn.Module):
    def __init__(self, dw, dr, dh, dp):
        super(PointerNet_SD, self).__init__()
        dhalf = dh//2
        self.embedding = Embedding(dw, dr, dhalf, dp)   # dim_in1, dim_in2, dim_half, dp
        self.encoder = Encoder(dh, dh)              # din, dout, #dp
        self.decoder = Decoder(dh, dp=dp)               # enc_dim, state_dim=6, dp=0.1

    def forward(self, sa, br, bw, bn, bm, nr, nw, son):
        emb_out = self.embedding(nw, nr, bn)
        if torch.isnan(emb_out).any():
            raise ValueError('Error0: nan exists in emb_out')
        enc_out, hc = self.encoder(emb_out)
        if torch.isnan(emb_out).any():
            raise ValueError('Error1: nan exists in enc_out')
        problem_info = sa, bw, br, bn, bm
        # sat_args, vtw_info, require_info, vtw_num, matrix_orbit = problem_info
        results, results_eval, probs = self.decoder(enc_out, hc, problem_info, son)

        return results, results_eval, probs



if __name__ == "__main__":

    # main 1：加载数据 以及 明确当前数据的保存路径
    # 1.1 加载数据
    data_type = True  # 真表示区域数据，假表示全球数据
    filepath0 = os.path.dirname(os.getcwd())  # 获取文件夹上一级的文件夹路径
    if data_type:
        # 训练数据包括 200，150，100，50 四种
        filepath1 = filepath0 + '\Data\FinalTraining_RD\FT_RD_'
        max_tar_num = 200
        num_sample_type = 4
    else:
        filepath1 = filepath0 + '\Data\FinalTraining_GD\FT_GD_'
        max_tar_num = 200
        num_sample_type = 4
    train_data = [[] for _ in range(num_sample_type)]

    tli = 0
    for num_tar in range(max_tar_num, 0, -50):
        path_name1 = filepath1 + str(num_tar) + '.pt'
        var_torch = torch.load(path_name1)  # torch_vtw, torch_nw, norm_data
        train_data[tli] = TrainDataset(var_torch)
        tli += 1

    task_num = 100
    if task_num == 200:
        di = 0
    elif task_num == 150:
        di = 1
    elif task_num == 100:
        di = 2
    elif task_num == 50:
        di = 3  # 其他情况都是3
    else:
        print('样本类型存在问题')

    train_data_sub = train_data[di]  # 0 200, 1 150, 2 100, 3 50
    # 1.2 保存路径
    algorithm_name = 'PN_SD_FLR_0_FLR001_o=5'
    time_str = '%s' % datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')
    now = time_str.replace('.', '')
    now = now.replace(' ', '_')
    now = now.replace(':', '')
    # path = filepath0 + '\\Result\\Training_Result\\RD_All\\' + algorithm_name + '_' + now
    path = filepath0 + '\\Result\\Training_Result\\RD_' + str(task_num) + '\\' + algorithm_name + '_' + now
    os.makedirs(path)
    fp = open(filepath0 + '\\Result\\Training_Result\\Training Log.txt', 'a', encoding='utf-8')
    fp.write('\n' + time_str + ' ' + algorithm_name + ' 训练结果保存路径：' + path)
    fp.close()
    print('\n训练结果保存路径：', path)
    path_writer = path + '\\log'
    writer = SummaryWriter(path_writer)

    # main 2: 参数设置
    # 2.1 卫星参数
    sat_parser = argparse.ArgumentParser(description='Parameters of AOS')
    sat_parser.add_argument('--orbit_times', default=14.20176543000019, type=float, help='24h内轨道圈次')
    sat_parser.add_argument('--orbit_period', default=24*60*60/14.20176543000019, type=float, help='平均轨道周期')
    sat_parser.add_argument('--energy', default=1500, type=float)
    sat_parser.add_argument('--memory', default=1000, type=float)
    sat_parser.add_argument('--eco_rate', default=1, type=float)  # 观测时能量消耗速率 *时间
    sat_parser.add_argument('--ect_rate', default=0.5, type=float)  # 姿态转换时能量消耗速率 *度数
    sat_parser.add_argument('--mc_rate', default=1, type=float)  # 内存消耗速率    *时间
    sat_parser.add_argument('--max_pitch', default=45, type=float)  # 俯仰角
    sat_parser.add_argument('--min_pitch', default=-45, type=float)  # 俯仰角
    sat_parser.add_argument('--max_roll', default=45, type=float)  # 滚动角
    sat_parser.add_argument('--min_roll', default=-45, type=float)  # 滚动角
    sat_parser.add_argument('--period', default=60 * 60 * 24, type=float)  # 调度周期
    SatArgs = sat_parser.parse_args()
    # 2.2 网络模型参数
    model_parser = argparse.ArgumentParser(description='Parameters of NetModel')
    model_parser.add_argument('--max_nt', default=600, type=int, help='能处理的最大任务数')
    model_parser.add_argument('--dim_vtw', default=4, type=int, help='窗口数据维度')
    model_parser.add_argument('--dim_require', default=2, type=int, help='需求数据维度')
    model_parser.add_argument('--hidden_dim', default=128, type=int, help='隐藏层维度')
    model_parser.add_argument('--drop_out', default=0.1, type=float, help='神经元停止概率')
    model_parser.add_argument('--scheduled_orbit_num', default=5, type=int, help='选择调度的轨道数量')
    ModelArgs = model_parser.parse_args()
    print('轨道范围：', ModelArgs.scheduled_orbit_num)
    # 2.3 训练参数
    train_parser = argparse.ArgumentParser(description='Parameters of training')
    train_parser.add_argument('--batch_size', default=128, type=int, help='批大小')
    train_parser.add_argument('--epochs', default=30, type=int, help='完整训练的轮次')
    train_parser.add_argument('--actor_lr', default=0.001, type=float, help='主网络学习率')
    train_parser.add_argument('--max_grad_norm', default=5., type=float, help='网络参数梯度的范数上限')
    TrainArgs = train_parser.parse_args()

    # main 3: 构建网络以及训练算法-测试
    step_size = 10
    step_sum = TrainArgs.epochs * 2560 / TrainArgs.batch_size

    actor = PointerNet_SD(ModelArgs.dim_vtw, ModelArgs.dim_require, ModelArgs.hidden_dim, ModelArgs.drop_out)
    # 可以选择不同的学习率设置
    actor_optim = optim.Adam(actor.parameters(), lr=TrainArgs.actor_lr)
    # actor_scheduler = optim.lr_scheduler.ExponentialLR(actor_optim, gamma=0.999)
    # actor_scheduler = Adaptive_CosAnneal_WarmRestart(actor_optim, total_steps=step_sum, step_size=step_size,
    #                                                  deacy_rate=0.01, min_lr=0.0001, min_lr_second=0.0005)
    actor.train()
    actor_losses, actor_rewards, actor_lr_list = [], [], []
    list_eval = []

    # main 4: 正式训练
    count_times = 0
    start_time = time.time()
    for epoch in range(TrainArgs.epochs):
        train_loader = DataLoader(train_data_sub, TrainArgs.batch_size, shuffle=True, drop_last=False) # 打乱样本顺序
        for batch_idx, batch in enumerate(train_loader):
            actor_lr = actor_optim.param_groups[0]['lr']
            batch_require, batch_vtw, batch_nw, batch_mo, batch_norm_require, batch_norm_vtw, _ = batch
            Results, ResultsEvaluation, probs = actor(SatArgs, batch_require, batch_vtw, batch_nw, batch_mo,\
                                                      batch_norm_require, batch_norm_vtw, ModelArgs.scheduled_orbit_num)
            # 输入：sa, br, bw, bn, bm, nr, nw, son
            # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
            # 开始训练
            reward = ResultsEvaluation[:, -1]
            logprob = torch.log(probs)
            if (logprob == float('-inf')).any():
                print('出现-inf', torch.where(logprob == float('-inf')))
                logprob[logprob == float('-inf')] = 0
            logprob = logprob.sum(1)  # 避免logprob全是0的情况
            target_reward = 1
            advantage = reward - target_reward
            actor_loss = torch.mean(advantage.detach() * logprob)

            actor_optim.zero_grad()
            actor_loss.backward()
            torch.nn.utils.clip_grad_norm_(actor.parameters(), TrainArgs.max_grad_norm)
            actor_optim.step()

            # 数据保存并可视化
            # actor
            actor_reward = torch.mean(reward).item()
            actor_rewards.append(actor_reward)
            actor_losses.append(actor_loss.item())
            actor_lr_list.append(actor_lr)

            writer.add_scalar('actor\\actor_reward', actor_reward, count_times)
            writer.add_scalar('actor\\actor_loss', actor_loss, count_times)
            writer.add_scalar('actor\\actor_lr', actor_lr, count_times)

            list_eval.append(ResultsEvaluation)

            # 以下是自适应学习率
            # if (actor_scheduler.step_count + 1) % step_size == 0:
            #     target_mean = target_reward  # torch.mean(target_reward)
            #     trend_actor, mean_actor = trend_mean(actor_rewards[-step_size:])
            #     actor_scheduler.step(restart=True, param=(trend_actor, mean_actor, target_mean))
            # else:
            #     actor_scheduler.step(restart=False)
            # actor_scheduler.step()

            count_times += 1

    writer.close()  # 关闭
    end_time = time.time()
    use_time = end_time - start_time
    print('用时：', use_time)

    # 画图
    # 1 actor的损失函数
    x1 = range(len(actor_losses))
    plt.figure(dpi=600, figsize=(16, 8))
    plt.subplot(3, 1, 1)
    plt.plot(x1, actor_losses, 'o-')
    plt.title('actor_loss')
    # 2 actor的收益值
    x2 = range(len(actor_rewards))
    plt.subplot(3, 1, 2)
    plt.plot(x2, actor_rewards, '.-')
    plt.title('actor_reward')
    # 3 actor学习率
    x3 = range(len(actor_lr_list))
    plt.subplot(3, 1, 3)
    plt.plot(x3, actor_lr_list, '.-')
    plt.title('actor_lr')
    plt_path = path + '\\' + algorithm_name + '_RD_' + str(num_tar) + '_' + now + '.jpg'
    plt.savefig(plt_path)
    plt.show()

    model_path = path + '\\' + algorithm_name + '_RD_' + str(num_tar) + '_' + now + '.pt'
    torch.save((actor.state_dict()), model_path)
    variable_path = path + '\\Results_' + algorithm_name + '_RD_' + str(num_tar) + '_' + now + '.pt'
    torch.save((Results, list_eval, actor_rewards, actor_losses, actor_lr_list,use_time), variable_path)
    a_test = torch.load(variable_path)