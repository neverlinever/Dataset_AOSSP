# 训练过程

# 编写时间：2023-2-21
# 修改时间：
# 作者：LZ

import numpy as np
import torch
from torch.optim.lr_scheduler import _LRScheduler

import math


def trend_mean(data):
    order = 1
    index = [i for i in range(1, len(data) + 1)]
    coeffs = np.polyfit(index, list(data), order)
    slope = coeffs[-2]
    return float(slope), np.mean(data)


class Adaptive_CosAnneal_WarmRestart(_LRScheduler):

    def __init__(self, optimizer, total_steps, step_size, deacy_rate, min_lr=0.0001, min_lr_second=0.0005):
        # Validate optimizer
        # if not isinstance(optimizer, Optimizer):
        #     raise TypeError('{} is not an Optimizer'.format(
        #         type(optimizer).__name__))
        self.optimizer = optimizer
        self.total_steps = total_steps
        self.step_size = step_size
        self.decay_rate = deacy_rate  # 指数衰减
        self.min_lr = min_lr
        self.min_lr_second = min_lr_second
        self.restart_lr = optimizer.param_groups[0]['lr']  # 只有一个优化器
        self.step_count = -1  # 表示步数计数,因为每次是为下一步的学习更新学习率,所以其值表示下一步的步数编号,从0开始
        self.step_rest = total_steps  # 重新开始衰减时的剩余的步数,即下一步要重新衰减前的剩余步数
        self.restart_step_i = 0  # self.restart_step_i + self.step_rest =  self.total_steps

        super(Adaptive_CosAnneal_WarmRestart, self).__init__(optimizer)

    def get_lr_decay(self):
        lr = self.optimizer.param_groups[0]['lr'] * (1 - self.decay_rate)
        self.optimizer.param_groups[0]['lr'] = max(lr, self.min_lr)

    def get_lr_restart(self, slope, truth, target):
        si = self.step_count - self.step_size
        difference = abs(target - truth)
        cos_slope = difference / target * math.pi / self.total_steps * math.sin(
            (si - self.restart_step_i) / self.step_rest * math.pi)
        if slope >= cos_slope:
            self.get_lr_decay()
        else:  # 重新设置学习率
            self.restart_step_i = self.step_count
            self.step_rest = self.total_steps - self.step_count
            current_lr = self.optimizer.param_groups[0]['lr']
            if self.restart_lr == self.min_lr:
                self.restart_lr = self.min_lr_second
            lr = current_lr + (self.restart_lr - current_lr) * difference / target  # lr不可能超过最大值
            self.optimizer.param_groups[0]['lr'] = lr
            self.restart_lr = lr

    def step(self, restart=False, param=None):
        self.step_count += 1
        if 0< self.step_count < self.total_steps:
            if restart:
                p1, p2, p3 = param
                self.get_lr_restart(p1, p2, p3)
            else:
                self.get_lr_decay()


if __name__ == "__main__":
    # 测试模型

    from ProblemModel import TrainDataset_original, generate_train_samples

    import pickle
    import argparse
    import torch.optim as optim
    from torch.utils.data import DataLoader
    import matplotlib.pyplot as plt
    import time

    # warnings.filterwarnings("ignore")

    # 载入数据
    filepath1 = 'Data_timewindows\SCSD_SS4\\RD_110000.data'
    with open(filepath1, 'rb') as f:  # Python 3: open(..., 'wb')   文件会自动关闭
        var_list = pickle.load(f)  # dataset

    # data_tar = var_list[0]  # 0纬度，1经度，2观测持续时间，3成像质量要求，4收益    # 成像质量需求已经用于初步处理时间窗了
    # data_VTW = var_list[1]  # ，①任务编号，②卫星编号，③轨道编号，④窗口编号，
    # #                                0          1        2           3
    # #     ⑤开始时间，⑥结束时间，⑦最大俯仰角， ⑧最小俯仰角，⑨斜率k，⑩截距b，（11）滚动角
    # #         4         5           6           7           8       9           10
    # data_nVTW = var_list[2]

    sat_parser = argparse.ArgumentParser(description='Parameters of AOS')
    # sat_parser.add_argument('--orbit_period', default=14.20176543000019, type=float) # 窗口信息中包含了轨道编号
    sat_parser.add_argument('--obs_times', default=50, type=int)
    sat_parser.add_argument('--energy', default=1200, type=float)
    sat_parser.add_argument('--memory', default=1000, type=float)
    sat_parser.add_argument('--eco_rate', default=1, type=float)  # 观测时能量消耗速率 *时间
    sat_parser.add_argument('--ect_rate', default=1, type=float)  # 姿态转换时能量消耗速率 *时间
    sat_parser.add_argument('--mc_rate', default=1, type=float)  # 内存消耗速率    *时间
    sat_parser.add_argument('--period', default=60 * 60 * 24, type=float)  # 调度周期
    sat_parser.add_argument('--max_pitch', default=45, type=float)  # 俯仰角
    sat_parser.add_argument('--min_pitch', default=-45, type=float)  # 俯仰角
    sat_parser.add_argument('--max_roll', default=45, type=float)  # 滚动角
    sat_parser.add_argument('--min_roll', default=-45, type=float)  # 滚动角
    # 转换时间和相关计算在ProblemModel文件中

    SatArgs = sat_parser.parse_args()

    
