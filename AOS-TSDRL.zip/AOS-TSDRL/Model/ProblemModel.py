# 问题的模型

# 编写时间：2023-3-17
# 修改时间：2023-4-20 修改姿态机动模型
# 修改时间：2023-10-31 修改姿态机动模型
# 作者：LZ

import torch
from Model.Calculate_Observation_Action import calculate_ost



# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 有GPU就用
device = torch.device("cpu")  # 先用CPU算

# 3.单步调度器
# 3.3 调度器
# # 已知每个任务的概率，待规划任务及其窗口，窗口信息，需求信息， 窗口数量信息，卫星属性，下一步的掩码矩阵
def scheduler_step(select_tasks, mask_vb, mask_ud, mask_n, current_state, b_vtw, b_require, b_nw, b_mo, sat_args,
                       o_list, t_key):
    """
    首先明确，都是batch数据
    :param select_tasks: tensor batch,      被选中的任务的索引
    :param mask_vb: torch.bool: batch      表示还没完成的样本为True,已完成的为False
    :param current_state: tensor batch,6    当前的状态   # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    :param mask_n: tenor batch,seq_len    当前轨道上可选的任务及其窗口

    :param mask_ud: tenor batch,seq_len   待规划任务

    :param b_vtw: tenor batch,seq_len,max_nw,9  窗口信息
    :param b_require: tenor batch,seq_len,2     需求信息    持续时间，优先级
    :param b_nw: tenor batch,seq_len    任务的窗口数量 `#b_index: tensor batch,seq_len    任务排序索引,没用到
    :param b_mo: tensor batch,sl,max_oi, 2, 任务是否分布在该轨道和对应窗口
    :param sat_args: 卫星属性参数
    :param o_list: 列表，样本数*[tensor(轨道数)],有任务分布的轨道编号，所以不同样本也是不一样的

    :param t_key: tensor, 样本数*任务数*2个轨道*2个特征（实际所在轨道，任务编号），跨轨道任务的窗口所在轨道可能不是实际轨道
    :return: 单步规划结果，更新后的状态，跟新后的next矩阵，待规划矩阵
    """
    # b_require:torch数组是一个batch的数据
    # 样本数*任务数*特征数  0观测持续时间，1收益    # 成像质量需求已经用于初步处理时间窗了
    # b_vtw # 样本数*任务数*窗口数*特征数 0任务编号，1卫星编号，2轨道编号，3窗口编号，
    #     4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
    # b_nw: 窗口数量

    # 1.初始值
    bz, sl = b_nw.size()  # sl是任务数

    reo = sat_args.eco_rate
    ret = sat_args.ect_rate
    rm = sat_args.mc_rate

    # 2.初始化返回值
    next_state = torch.zeros([bz, 7])  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    scheduling_results = torch.zeros([bz, 8])
    # 0选择的动作即任务，1是否能执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7收益

    select_index = torch.zeros(bz, dtype=int) - 1  # 表示每个样本选择的索引，初始化为-1
    deleted_index = [[] for _ in range(bz)]     # 每个样本被舍弃的任务

    # 3.逐个样本实现单步规划
    # 测试概率出现nan值--------------------------------------------------------开始-----------------------------------
    # for bi in range(bz):
    #     if mask_vb[bi] & (torch.isnan(task_pro[bi,:])).any():
    #         print('样本未完成但概率有nan值', bi)
    # 测试概率出现nan值--------------------------------------------------------结束-----------------------------------
    for bi in range(bz):  # 逐个样本判断
        if not mask_vb[bi]:  # 假表示该样本已完成规划
            continue
        # st = time.time()
        # 状态 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        state0 = current_state[bi, 1:5]  # 0开始时间，1结束时间，2俯仰角，3侧摆角,只用于计算动作
        curr_tasks = torch.where(mask_n[bi, :] >= 0)[0]     # 当前待规划的任务索引
        # 详尽测试-------------------------------------------------------------开始-------------------------------------
        # for ti in range(sl):
        #     if task_pro[bi, ti]==0:
        #         if mask_n[bi,ti]>=0:
        #             print('错误0：概率为0但是带规划：', bi, ti)
        #         continue
        #     if task_pro[bi, ti]<0 or task_pro[bi, ti]>1:
        #         print('错误1：概率超出范围：', bi, ti, task_pro[bi, ti])
        #     else:
        #         if mask_ud[bi,ti]!=0:
        #             print('错误2：有概率但是已规划', bi, ti)
        #         if mask_n[bi,ti]==-1:
        #             print('错误3：有概率但是不是待规划任务', bi, ti)
        # 测试完毕-------------------------------------------------------------结束-------------------------------------
        # et1 = time.time()
        # print('1 测试用时', et1 - st)
        # 3.1 选择概率最大的动作

        ni = select_tasks[bi]  # ni 是next矩阵中的索引，动作索引，代表选择的任务

        # if task_pro[bi, ni] == 0:   # 测试用!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        #     print('3.1错误，被选任务的概率为0！')

        select_index[bi] = ni  # 选中的索引

        ws = []  # 可供选择的窗口
        # 有小概率这一个窗口在当前轨道上，下一个窗口在下一个轨道上
        flag_complete_task = False  # 该任务是否成功执行的标志符
        if mask_n[bi, ni] < 2:
            ws.append(t_key[bi, ni, mask_n[bi, ni], 1])
            w_count = mask_n[bi, ni] - 1
        else:
            w_count = -1
            for index in range(2):
                ws.append(t_key[bi, ni, index, 1])

        for wi in ws:  # wi必然是在当前两个轨道上的窗口
            # 3.1.1 判断可行性及生成观测动作
            # (1)先计算能否生成新动作，姿态转换时间是否满足
            # if b_vtw[bi, ni, wi, 4:].sum() == 0:  # !!!!!!!!!!!!!!!!!!!!!!!测试用，后删
            #     print('全是0', [bi, ni])
            is_done, state1 = calculate_ost(state0.tolist(), b_vtw[bi, ni, wi, 4:].tolist(), b_require[bi, ni, 0].tolist())
            # 备注calculate_ost(oa0, vtw_info, d):
            # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
            #                               0   1  2  3
            # vtw_info：窗口信息: 最早开始时间，最晚开始时间，k，b，滚动角
            #                       0               1         2  3    4
            # d：表示任务持续时间 # b_require[bi, task_id, 2]持续时间
            #  b_vtw:4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
            if not is_done:  # 该动作没有成功生成
                # print('1 动作无法生成')
                continue  # 不满足条件就判断下一个窗口
            state1 = torch.tensor(state1)

            # 分两大类进行讨论
            if b_vtw[bi, ni, wi, 2] == current_state[bi, 0]:     # 还在同一个轨道
                rest_memory = current_state[bi, 5]  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                rest_energy = current_state[bi, 6]
            else:   # 不在同一个轨道
                rest_memory = sat_args.memory
                rest_energy = sat_args.energy
            # 存储和能量约束判断
            # （2）计算观测所需的内存和能量,并判断观测内存可行性
            con_memory = b_require[bi, ni, 1] * rm
            con_energy_o = b_require[bi, ni, 1] * reo  # 观测所需的能量
            if con_memory > rest_memory:  # 所需大于剩余
                # 如果刚进入一个新轨道，那么这两个条件必然是满足的
                # print('2 存储不满足约束', con_memory, rest_memory)
                continue  # 不满足条件就判断下一个窗口

            # （3）继续判断动作转换是否满足能量约束
            con_energy_t = (abs(state0[2] - state1[2]) + abs(state0[3] - state1[3])) * ret  # 以度数来计算
            if con_energy_t + con_energy_o > rest_energy:
                # print('3 能量不满足约束', con_energy_t + con_energy_o, rest_energy)
                continue  # 不满足条件就判断下一个任务
            flag_complete_task = True
            w_count += 1    # flag_complete_task为真，w_count必然>0
            wi_selected = wi
            break
        # 至此完成了当前轨道上的一个任务规划
        # et2 = time.time()
        # print('2 选择一个任务完成规划用时：', et2 - et1)

        curr_tasks = curr_tasks[curr_tasks.ne(ni)]  # 删除被选中的任务后剩余当前待规划任务
        # 更新调度方案和执行完任务后的卫星状态、undone值
        if flag_complete_task:  # 表明该任务成功执行
            # if t_key[bi, ni, w_count, 0] == 0:    # 测试-------------------------------
            #     print('检索表中轨道编号为0')
            # 3.2  任务成功执行更新单步调度方案和对应矩阵mask_ud、mask_n、mask_nw
            # 3.2.1  单步调度方案，在不在当前轨道都一样
            current_oi = b_vtw[bi, ni, wi_selected, 2]  # 该窗口所在的轨道
            # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
            scheduling_results[bi, 0] = ni  # 任务编号
            scheduling_results[bi, 1] = 1  # 成功执行
            scheduling_results[bi, 2] = t_key[bi, ni, w_count, 0]   # 表示规划所在轨道，跨轨窗口其值可能不等于轨道编号
            scheduling_results[bi, 3: 7] = state1  # [st,et,pa,ra]
            scheduling_results[bi, 7] = b_require[bi, ni, 1]  # 收益

            # 3.2.2 执行完任务后的状态, 考虑到可能存在跨轨道任务
            # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            next_state[bi, 0] = state1[1] // sat_args.orbit_period + 1  # 轨道编号
            next_state[bi, 1:5] = state1
            if next_state[bi, 0] == current_oi:  # 保险一点的写法
                next_state[bi, 5] = rest_memory - con_memory
                next_state[bi, 6] = rest_energy - con_energy_t - con_energy_o
            else:
                next_state[bi, 5] = sat_args.memory
                next_state[bi, 6] = sat_args.energy
            # if next_state[bi, 5] == 0 or next_state[bi, 6] == 0:
            #     print('剩余存储或约束为0')
            # 3.2.3  更新当前任务的undone值
            mask_ud[bi, ni] = 1

            for dti in curr_tasks:  # 去掉选择的任务后的当前待规划的任务逐个判断
                if b_vtw[bi, dti, b_nw[bi, dti]-1, 5] < state1[1]:  # 直接判断最后一个窗口最晚开始时间是否早于动作结束时间
                    mask_ud[bi, dti] = -1  # 舍弃
                    deleted_index[bi].append(dti)  # 放弃的任务
            # et3 = time.time()
            # print('3 执行成功更新信息用时：', et3 - et2)
            # 测试是否删除干净了-----------------------------------------------------------------------------------
            # task_ud = torch.where(mask_ud[bi, :] == 0)[0]  # 找出未规划任务的索引
            # if min(task_ud.shape) != 0:  # 不空
            #     for cti in task_ud:
            #         if b_vtw[bi, cti, b_nw[bi, cti]-1, 5] < state1[1]:  # 最后一个窗口的最晚开始时间在当前轨道之前
            #             print('删除测试1：应该删除但是没有删除：', bi, cti, b_vtw[bi, cti, b_nw[bi, cti]-1, 5], state1[1])
            # # 测试是否多删除
            # for cti in deleted_index[bi]:
            #     if b_vtw[bi, cti, b_nw[bi, cti]-1, 5] >= state1[1]:  # 最后一个窗口的最晚开始时间在当前轨道之后
            #         print('删除测试2：不应该删除但是被删除了：', bi, cti, b_vtw[bi, cti, b_nw[bi, cti] - 1, 5], state1[1])
            # 测试--------------------------------------------结束-------------------------------------------------
            # et4 = time.time()
            # print('4 执行成功后删除信息判断用时：', et4 - et3)
        else:
            # 3.3 执行不成功, 更新单步调度方案、状态和对应矩阵mask_ud
            # 3.3.1 更新方案
            # current_oi = current_state[bi, 0]  # 还在当前轨道
            # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
            scheduling_results[bi, 0] = ni  # 任务编号
            scheduling_results[bi, 1] = 0  # 执行失败
            scheduling_results[bi, 2] = b_vtw[bi, ni, wi, 2]  # 该窗口所在的轨道
            scheduling_results[bi, 3: 5] = b_vtw[bi, ni, wi, 4:6]  # [st,et,maxpa,minpa]
            scheduling_results[bi, 7] = b_require[bi, ni, 1]  # 收益

            # 3.3.2 执行完任务后的状态
            # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            next_state[bi, :] = current_state[bi, :]  # 保持不变

            # 3.3.3  更新当前任务的undone值
            mask_ud[bi, ni] = -1  # 放弃
            # et3 = time.time()
            # print('3 执行失败更新信息用时：', et3 - et2)

        # 3.4 继续更新下一阶段的next和o_scheduled矩阵,next轨道next_state[bi, 0]
        # 先对当前next和nw值初始化
        current_oi = int(next_state[bi, 0])
        mask_n[bi, :] = -1   # 初始化 下阶段待规划的任务
        t_key[bi, :, :, :] = 0  # 初始化任务检索表
        task_ud = torch.where(mask_ud[bi, :] == 0)[0]  # 找出未规划任务的索引

        if min(task_ud.shape) != 0:  # 不空, 此时剩余轨道不可能没有
            count_o = 0  # 有任务的轨道数
            if current_oi > o_list[bi][0]:
                oi = current_oi - 1
                task_oi = torch.where(b_mo[bi, :, oi, 0])[0]  # 在该轨道上的任务
                if task_oi.numel() > 0:  # 该轨道上有任务
                    flag_ud = mask_ud[bi, task_oi] == 0  # 未规划的任务位置上为真
                    if flag_ud.any():  # 真表示该轨道上有任务未规划
                        # 未规划可能的原因：一是跨轨道任务，二是有窗口在后续的轨道上
                        task_ou = task_oi[flag_ud]  # 该轨道上未规划的任务索引
                        for ti in task_ou:  # 逐个任务判断
                            wi = b_mo[bi, ti, oi, 1]    # 窗口
                            if b_vtw[bi, ti, wi, 5] >= next_state[bi, 2]:
                                mask_n[bi, ti] = 0
                                t_key[bi, ti, 0, 0] = current_oi    # 窗口最晚开始时间所在轨道
                                t_key[bi, ti, 0, 1] = wi
                                count_o = 1

            task_oi = torch.where(b_mo[bi, :, current_oi, 0])[0]  # 在该轨道上的任务
            if task_oi.numel() > 0:  # 该轨道上有任务
                flag_ud = mask_ud[bi, task_oi] == 0  # 未规划的任务位置上为真
                if flag_ud.any():  # 真表示该轨道上有任务未规划
                    task_ou = task_oi[flag_ud]  # 该轨道上未规划的任务索引
                    mask_n[bi, task_ou] = 0     # 此处的任务与跨轨道的任务不可能重复
                    t_key[bi, task_ou, 0, 0] = current_oi
                    t_key[bi, task_ou, 0, 1] = b_mo[bi, task_ou, current_oi, 1]
                    count_o = 1

            rest_orbit = o_list[bi]
            rest_orbit = rest_orbit[rest_orbit.gt(current_oi)]  # 编号大于当前轨道的轨道
            # 因为任务的删除，剩余的轨道上有可能没有任务了
            for oi in rest_orbit:
                task_oi = torch.where(b_mo[bi, :, oi, 0])[0]   # 在该轨道上的任务
                # if task_oi.numel() == 0:    # 该轨道上没有任务，报错---------------测试-------------------------
                #     print(' 该轨道上没有任务，报错')
                #     continue
                flag_ud = mask_ud[bi, task_oi] == 0  # 未规划的任务位置上为真
                if flag_ud.any():   # 真表示有任务在该轨道上
                    task_ou = task_oi[flag_ud]  # 该轨道上未规划的任务索引
                    t_key[bi, task_ou, count_o, 0] = int(oi)
                    t_key[bi, task_ou, count_o, 1] = b_mo[bi, task_ou, oi, 1]
                    count_o += 1
                    mask_n[bi, task_ou] += count_o
                    # count_o=1时，表示在第一个轨道上，初始next值肯定是-1，结果是0
                    # count_o=2时，表示在第二个轨道上，初始next值是-1或0，结果是1或2
                    if count_o >= 2:    # 2个轨道上的任务next值更新完毕
                        break

            # 结束循环oi
            # if (mask_n[bi, :].eq(-1)).all():
            #     print('错误：没有下阶段的规划任务', bi)# 测试任务的undone和next是否匹配---------------------------------

            # 测试当前未规划任务是否有已经无法执行的任务----------------------------开始--------------------------------
            # for uti in task_ud:
            #     if b_vtw[bi, uti, b_nw[bi, uti]-1, 5] < next_state[bi, 2]:
            #         print('该任务未规划但窗口在执行结束之前', bi, uti)
            #     else:
            #         if b_vtw[bi, uti, b_nw[bi, uti]-1, 2] < next_state[bi, 0] - 1:  # 可能是跨轨道的窗口
            #             print('该窗口未规划但所在轨道在当前轨道前一个轨道之前', bi, uti)
            # 测试结束--------------------------------------------------------------结束--------------------------------
            # et4 = time.time()
            # print('4 更新下一步信息用时：', et4 - et3)

        else:   # 没有带规划任务
            mask_vb[bi] = False  # 该样本规划结束

        # et5 = time.time()
        # print('5 单步调度器一次循环用时：', et5 - st)

        # 终极测试，判断一个样本更新后的数据是否匹配----------------------------测试------------------------------------
        """
        # 1 是否存在应删未删
        task_ud = torch.where(mask_ud[bi, :] == 0)[0]  # 找出未规划任务的索引
        for ti in task_ud:
            if b_vtw[bi, ti, b_nw[bi, ti]-1, 5] < next_state[bi, 2]:
                print('错误1：应删未删:', bi, ti)

        # 3 待规划却已执行或没窗口
        task_n = torch.where(mask_n[bi, :] > -1)[0]  # 找出已删除任务的索引
        for ti in task_n:
            if mask_ud[bi, ti] != 0:
                print('错误3.1：待规划却已执行：', bi, ti)
            # if b_vtw[bi, ti, b_nw[bi, ti]-1, 5] < next_state[bi, 2]:
            #     print('错误3.2：待规划却无法执行：', bi, ti)
            if mask_n[bi, ti] == 0:  # 只有一个窗口在第一个轨道上待规划
                wi = t_key[bi, ti, mask_n[bi, ti], 1]
                if ~(b_vtw[bi, ti, wi, 2] <= t_key[bi, ti, 0, 0] >= next_state[bi, 0]):
                    print('错误3.3.1：待规划任务的next与t_key不匹配：', bi, ti)
                if t_key[bi, ti, 1, 0] != 0 or t_key[bi, ti, 1, 1] != 0:
                    print('错误3.3.3：待规划任务的next与t_key不匹配：', bi, ti)
            elif mask_n[bi, ti] == 1:  # 只有一个窗口在第二个轨道上待规划:
                wi = t_key[bi, ti, mask_n[bi, ti], 1]
                if ~(b_vtw[bi, ti, wi, 2] == t_key[bi, ti, 1, 0] > next_state[bi, 0]):
                    print('错误3.3.1：待规划任务的next与t_key不匹配：', bi, ti)
                if t_key[bi, ti, 0, 0] != 0 or t_key[bi, ti, 0, 1] != 0:
                    print('错误3.3.3：待规划任务的next与t_key不匹配：', bi, ti)
            else:   # mask_n[bi, ti] == 2
                wi = t_key[bi, ti, 0, 1]
                if ~(b_vtw[bi, ti, wi, 2] <= t_key[bi, ti, 0, 0] >= next_state[bi, 0]):
                    print('错误3.3.1：待规划任务的next与t_key不匹配：', bi, ti)
                wi = t_key[bi, ti, 1, 1]
                if ~(b_vtw[bi, ti, wi, 2] == t_key[bi, ti, 1, 0] > next_state[bi, 0]):
                    print('错误3.3.3：待规划任务的next与t_key不匹配：', bi, ti)
        """
        # ----------------------------------------测试 结束------------------------- -----------------------------------
    return mask_vb, select_index, deleted_index, scheduling_results, next_state, mask_ud, mask_n, t_key


def scheduler_ls_od(prob, son, curr_orbit, orbit_list, curr_state, mask_s, mask_ud, b_vtw, b_require, b_nw, b_mo, sat_args):
    # 1.初始值
    bz, sl, mnw, _ = b_vtw.size()
    reo = sat_args.eco_rate
    ret = sat_args.ect_rate
    rm = sat_args.mc_rate
    orbit_period = sat_args.orbit_period

    # matrix_n = torch.zeros([bz, sl, mnw]).bool()   # 任务的窗口是否在当前调度轨道上

    # 2.初始化返回值
    next_state = torch.zeros([bz, 7])  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    scheduling_results = torch.zeros([bz, 8])
    # 0选择的动作即任务，1是否能执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7收益
    select_index = torch.zeros(bz, dtype=int) - 1  # 表示每个样本选择的索引，初始化为-1
    deleted_index = [[] for _ in range(bz)]  # 每个样本被舍弃的任务

    # 3.逐个样本实现单步规划，每一次解码只有两个结果：（1）选中一个任务成功规划，（2）删除所有剩余未规划任务
    b_list = torch.nonzero(mask_s, as_tuple=True)[0].tolist()  # 还需要规划的样本是true,其余False
    for bi in b_list:
        # 状态 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        state0 = curr_state[bi, 1:5]  # 0开始时间，1结束时间，2俯仰角，3侧摆角,只用于计算动作
        flag_complete_task = False  #  是否完成一个任务的调度
        # 3.1: 确定未规划任务
        tu_tensor = torch.nonzero(mask_ud[bi, :] == 0, as_tuple=True)[0]  # 当前样本中未规划任务tensor数组
        if tu_tensor.numel() == 0:  # 没有未规划任务
            raise ValueError('Error-scheduler_ls_od: 3 no unscheduled tasks!')
        # 3.2：确定候选任务
        flag_complete_schedule = False      # 是否完成调度调度
        while not flag_complete_schedule:
            # 轨道上可能没有候选任务，任务在之前轨道上已经规划完了
            matrix_n = torch.zeros([sl, mnw]).bool()  # 任务的窗口是否在当前调度轨道上
            ct_list = []    # 候选任务列表
            count_o = 0
            coi = 0
            while count_o < son:
                o_index = curr_orbit[bi] + coi  # 轨道索引
                if o_index >= len(orbit_list[bi]):  # 超出范围
                    break
                oi = orbit_list[bi][o_index]  # 轨道编号
                oct_list = torch.where(b_mo[bi, tu_tensor, oi, 0] == 1)[0].tolist()  # 未规划任务在当前轨道上的任务
                # oct_list是tu_tensor中的索引
                if oct_list:    # 该轨道上 有未规划任务
                    oct_tensor = tu_tensor[oct_list]  # 实际的任务索引
                    count_o += 1    # 有效计数
                    ct_list += oct_tensor.tolist()
                    for octi in oct_tensor:
                        octwi = b_mo[bi, octi, oi, 1]  # 对应的窗口编号
                        matrix_n[octi, octwi] = True  # 该任务的窗口为真
                coi += 1
            if not ct_list:     # 没找到候选任务
                raise ValueError('Error-scheduler_ls_od: 3.2 no candidate tasks!')
            # 调度轨道上的任务列表生成ct_list，以及相应的轨道窗口矩阵matrix_n
            ct_tensor = torch.unique(torch.tensor(ct_list))   # 去重 得到候选任务列表,tensor类型
            ct_prob = prob[bi, ct_tensor]   # 候选任务的概率
            prob_sort, ct_sort = torch.sort(ct_prob, descending=True)  # 降序排列
            sct_tensor = ct_tensor[ct_sort]   # ct_sort中只是索引,得到按概率降序排列的候选任务

            # 3.3：对候选任务逐个判断能否顺利调度
            for ti in sct_tensor:
                ctw_tensor = torch.where(matrix_n[ti, :])[0]   # 该任务在调度轨道上的窗口
                if ctw_tensor.numel() == 0:  # 没有窗口
                    raise ValueError('Error-scheduler_ls_od: 3.3 no VTW!')
                # 可能存在多个轨道，逐个轨道判断，优先选靠前的窗口
                for wi in ctw_tensor:
                    # 3.1.1 判断可行性及生成观测动作
                    # (1)先计算能否生成新动作，姿态转换时间是否满足
                    is_done, state1 = calculate_ost(state0.tolist(), b_vtw[bi, ti, wi, 4:].tolist(),
                                                    b_require[bi, ti, 0].tolist())
                    # 备注calculate_ost(oa0, vtw_info, d):
                    # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
                    #                               0   1  2  3
                    # vtw_info：窗口信息: 最早开始时间，最晚开始时间，k，b，滚动角
                    #                       0               1         2  3    4
                    # d：表示任务持续时间 # b_require[bi, task_id, 0]持续时间
                    #  b_vtw:4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
                    if not is_done:  # 该动作没有成功生成
                        continue  # 不满足条件就判断下一个窗口
                    state1 = torch.tensor(state1)   # state1 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量

                    # (2) 确定观测当作是在否在当前轨道上完成的，确定剩余能量和内存。分两大类进行讨论
                    soi = state1[1]//orbit_period + 1  # 轨道编号从1开始
                    if soi == curr_state[bi, 0]:  # 还在同一个轨道
                        rest_memory = curr_state[bi, 5]  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                        rest_energy = curr_state[bi, 6]
                    else:  # 不在同一个轨道
                        rest_memory = sat_args.memory
                        rest_energy = sat_args.energy
                    # （3） 存储和能量约束判断计算观测所需的内存和能量,并判断观测内存可行性
                    con_memory = b_require[bi, ti, 0] * rm
                    con_energy_o = b_require[bi, ti, 0] * reo  # 观测所需的能量
                    if con_memory > rest_memory:  # 所需大于剩余
                        # 如果刚进入一个新轨道，那么这两个条件必然是满足的
                        # print('2 存储不满足约束', con_memory, rest_memory)
                        continue  # 不满足条件就判断下一个窗口

                    # （3）继续判断动作转换是否满足能量约束
                    con_energy_t = (abs(state0[2] - state1[2]) + abs(state0[3] - state1[3])) * ret  # 以度数来计算
                    if con_energy_t + con_energy_o > rest_energy:
                        # print('3 能量不满足约束', con_energy_t + con_energy_o, rest_energy)
                        continue  # 不满足条件就判断下一个任务
                    flag_complete_task = True
                    select_index[bi] = ti
                    # wi_selected = wi
                    break   # 选中了一个可行窗口,中断循环
                if flag_complete_task:   # 有任务成功调度，跳出循环
                    break
            # 至此完成了当前任务的可行窗口选择,两种情况:选中了一个窗口并成功规划,或没有成功规划

            # 3.4：执行成功 更新调度方案和执行完任务后的卫星状态、undone值、curr_orbit[bi]
            if flag_complete_task:  # 表明该任务成功执行
                flag_complete_schedule = True   # 完成了单步调度
                # 3.4.1  单步调度方案，根据开始时间定所在轨道
                # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
                scheduling_results[bi, 0] = select_index[bi]  # 任务编号
                scheduling_results[bi, 1] = 1  # 成功执行
                scheduling_results[bi, 2] = soi  # 表示规划所在轨道，跨轨窗口其值可能不等于轨道编号
                scheduling_results[bi, 3: 7] = state1  # [st,et,pa,ra]
                scheduling_results[bi, 7] = b_require[bi, select_index[bi], 1]  # 收益
                # 3.4.2 执行完任务后的状态, 考虑到可能存在跨轨道任务
                # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                eoi = state1[2] // orbit_period + 1  # 用当作结束时间计算卫星状态所在轨道
                next_state[bi, 0] = eoi
                next_state[bi, 1:5] = state1
                if eoi == soi:
                    next_state[bi, 5] = rest_memory - con_memory
                    next_state[bi, 6] = rest_energy - con_energy_t - con_energy_o
                else:
                    next_state[bi, 5] = sat_args.memory
                    next_state[bi, 6] = sat_args.energy
                # 3.4.3 更新当前任务的状态,并粗筛
                mask_ud[bi, select_index[bi]] = 1  # 当前选中的任务
                uct_list = ct_tensor[torch.ne(ct_tensor, select_index[bi])].tolist()  # 剩余的任务
                # 后面再尝试从所有未规划任务中删除
                for dti in uct_list:
                    if b_vtw[bi, dti, b_nw[bi, dti] - 1, 5] < state1[1]:
                        # 直接判断最后一个窗口最晚开始时间是否早于动作结束时间
                        mask_ud[bi, dti] = -1  # 舍弃
                        deleted_index[bi].append(dti)  # 放弃的任务
                # 3.4.4 更新curr_orbit[bi]值，下一次规划起始的轨道索引，并判断是否样本调度是否完成
                # eoi表示更新后的状态所在的轨道
                if eoi > orbit_list[bi][-1]:    # 轨道超出范围
                    mask_s[bi] = False  # 该样本调度完成
                    if torch.nonzero(mask_ud[bi, :] == 0, as_tuple=True)[0].numel() != 0:
                        raise ValueError('Error-scheduler_ls_od: 3.4.4 current orbit index exceeds range, \
                        but unscheduled tasks exit!')
                else:
                    curr_orbit[bi] = torch.where(orbit_list[bi] >= eoi)[0][0].data
                    if torch.nonzero(mask_ud[bi, :] == 0, as_tuple=True)[0].numel() == 0:
                        mask_s[bi] = False   # 该样本调度完成
                    else:  # 还有未规划任务，但是轨道索引已经超出范围了
                        if curr_orbit[bi] >= len(orbit_list[bi]):  # 超出范围
                            raise ValueError('Error-scheduler_ls_od: 3.4.4 current orbit index exceeds range!')

            # 3.5 执行不成功 更新轨道继续循环
            else:
                # 首先判断是否有后续轨道，没有的话当前候选任务全部删除，有的话对当前候选任务判断是否有后续调度机会
                # 后续的轨道索引 curr_orbit[bi] + coi
                no_index = curr_orbit[bi] + coi
                if no_index >= len(orbit_list[bi]):
                    # （1） 后续的轨道已经超出范围，即没有后续轨道了，当前候选任务全部删除
                    mask_ud[bi, ct_tensor] = -1  # 候选任务全部删除
                    deleted_index[bi] += ct_tensor.tolist()  # 拼接
                    flag_complete_schedule = True  # 单步调度完成
                    mask_s[bi] = False   # 该样本规划完成

                    if torch.nonzero(mask_ud[bi, :] == 0, as_tuple=True)[0].numel() != 0:
                        # 如果还有未规划任务，报错
                        raise ValueError('Error-scheduler_ls_od: 3.5(1) still exist unscheduled tasks!')
                    # continue    # 下一个样本

                else:  # （2）有后续轨道，但是需要判断还有没有后续任务,可能没有后续任务了
                    noi = orbit_list[bi][no_index]   # 实际轨道编号
                    # 逐个候选任务判断是否有后续调度机会，即最后一个窗口是否在后续的轨道上
                    for dti in ct_tensor.tolist():
                        if b_vtw[bi, dti, b_nw[bi, dti] - 1, 2] < noi:
                            mask_ud[bi, dti] = -1   # 删除
                            deleted_index[bi].append(dti)
                    # 对当前候选任务判断完
                    if torch.nonzero(mask_ud[bi, :] == 0, as_tuple=True)[0].numel() != 0:
                        # 如果有未规划任务，更新起始调度轨道
                        curr_orbit[bi] = no_index
                        flag_complete_schedule = False  # 继续循环单步调度
                    else:   # 没有未规划任务，调度结束
                        mask_s[bi] = False  # 该样本规划完成
                        flag_complete_schedule = True  # 单步调度完成
                        if torch.nonzero(mask_ud[bi, :] == 0, as_tuple=True)[0].numel() != 0:
                            # 如果还有未规划任务，报错
                            raise ValueError('Error-scheduler_ls_od: 3.5(2) still exist unscheduled tasks!')
        # 至此，一个样本的单步调度完成
    # 至此，所有未规划样本的单步调度完成，下面返回值
    # 返回值包括：单步调度结果，卫星状态，选中的任务，删除的任务，更新的mask_s，更新的mask_ud，更新的curr_orbit
    # 任务调度成功：具有有效值    更新      >=0
    # 任务调度失败：为0         0无意义    -1      原所有未规划任务 样本调度完成   原为-1         值无意义
    return scheduling_results, next_state, select_index, deleted_index, mask_s, mask_ud, curr_orbit








# 以下的调度器是根据时段来决策的
def step_scheduler_new(prob, b_list, mask_ud, matrix_n, current_state, b_vtw, b_require, b_nw, sat_args):
    """

    :param prob: tensor, bs,sl          任务的概率
    :param b_list: list batch      表示还没完成的样本的索引
    :param mask_ud: tenor batch,seq_len   待规划任务
    :param matrix_n: tenor.bool batch,seq_len, max_nw  任务的该窗口在轨道上为True, 否则为False
    :param current_state: tensor batch,6    当前的状态   # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    :param b_vtw: tenor batch,seq_len,max_nw,9  窗口信息 [0任务编号，1卫星编号，2轨道编号，3窗口编号，4开始时间，5结束时间，6斜率k，7截距b，8滚动角]
    :param b_require: 需求信息    持续时间，优先级
    :param b_nw: 任务的窗口数量 `#b_index: tensor batch,seq_len
    :param sat_args: 卫星属性参数
    :return:  单步规划结果，更新后的卫星状态,更新后的mask_ud
    """

    # 1.初始值
    bz, sl = b_nw.size()  # sl是任务数
    reo = sat_args.eco_rate
    ret = sat_args.ect_rate
    rm = sat_args.mc_rate
    orbit_period = sat_args.orbit_period    # 轨道周期

    # 2.初始化返回值
    next_state = torch.zeros([bz, 7])  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    scheduling_results = torch.zeros([bz, 8])
    # 0选择的动作即任务，1是否能执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7收益
    select_index = torch.zeros(bz, dtype=int) - 1  # 表示每个样本选择的索引，初始化为-1
    record_index = [[] for _ in range(bz)]  # 每个样本被舍弃的任务

    # 3.逐个样本实现单步规划
    for bi in b_list:  # 逐个样本判断
        # 状态 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        state0 = current_state[bi, 1:5]  # 0开始时间，1结束时间，2俯仰角，3侧摆角,只用于计算动作
        # current_state 状态 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        # 3.1 降序排列,找合适的任务
        prob_sorted, t_sorted = torch.sort(prob[bi, :], descending=True)    # 降序排列
        temp_indexes = torch.where(prob_sorted > 0)[0].tolist()  # 找出大于0的索引
        curr_tasks = t_sorted[: temp_indexes[-1]].tolist()  # 降序排序后当前待规划的任务索引 候选任务集合
        flag_complete_task = False  # 是否有任务成功执行的标志符
        for ti in curr_tasks:  # 按照顺序判断该任务可行否
            w_list = torch.where(matrix_n[bi, ti, :])[0].tolist()   # 找出真值索引,即窗口编号
            for wi in w_list:
                # 3.1.1 判断可行性及生成观测动作
                # (1)先计算能否生成新动作，姿态转换时间是否满足
                is_done, state1 = calculate_ost(state0.tolist(), b_vtw[bi, ti, wi, 4:].tolist(),
                                                b_require[bi, ti, 0].tolist())
                # 备注calculate_ost(oa0, vtw_info, d):
                # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
                #                               0   1  2  3
                # vtw_info：窗口信息: 最早开始时间，最晚开始时间，k，b，滚动角
                #                       0               1         2  3    4
                # d：表示任务持续时间 # b_require[bi, task_id, 2]持续时间
                #  b_vtw:4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
                if not is_done:  # 该动作没有成功生成
                    continue  # 不满足条件就判断下一个窗口
                state1 = torch.tensor(state1) # state1 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                # 分两大类进行讨论
                soi = state1[1]//orbit_period + 1  # 轨道编号从1开始
                if soi == current_state[bi, 0]:  # 还在同一个轨道
                    rest_memory = current_state[bi, 5]  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                    rest_energy = current_state[bi, 6]
                else:  # 不在同一个轨道
                    rest_memory = sat_args.memory
                    rest_energy = sat_args.energy

                # （2） 存储和能量约束判断计算观测所需的内存和能量,并判断观测内存可行性
                con_memory = b_require[bi, ti, 1] * rm
                con_energy_o = b_require[bi, ti, 1] * reo  # 观测所需的能量
                if con_memory > rest_memory:  # 所需大于剩余
                    # 如果刚进入一个新轨道，那么这两个条件必然是满足的
                    # print('2 存储不满足约束', con_memory, rest_memory)
                    continue  # 不满足条件就判断下一个窗口

                # （3）继续判断动作转换是否满足能量约束
                con_energy_t = (abs(state0[2] - state1[2]) + abs(state0[3] - state1[3])) * ret  # 以度数来计算
                if con_energy_t + con_energy_o > rest_energy:
                    # print('3 能量不满足约束', con_energy_t + con_energy_o, rest_energy)
                    continue  # 不满足条件就判断下一个任务
                flag_complete_task = True
                record_index[bi].append(ti)  # 成功规划的任务
                select_index[bi] = ti
                # wi_selected = wi
                break   # 选中了一个可行窗口,中断循环

            # 至此完成了当前任务的可行窗口选择,两种情况:选中了一个窗口并成功规划,或没有成功规划
            # 更新调度方案和执行完任务后的卫星状态、undone值
            if flag_complete_task:  # 表明该任务成功执行
                # 3.2  任务成功执行更新单步调度方案,卫星执行完任务后的状态,对应矩阵mask_ud
                # 3.2.1  单步调度方案，根据开始时间定所在轨道
                # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
                scheduling_results[bi, 0] = ti  # 任务编号
                scheduling_results[bi, 1] = 1  # 成功执行
                scheduling_results[bi, 2] = soi  # 表示规划所在轨道，跨轨窗口其值可能不等于轨道编号
                scheduling_results[bi, 3: 7] = state1  # [st,et,pa,ra]
                scheduling_results[bi, 7] = b_require[bi, ti, 1]  # 收益
                # 3.2.2 执行完任务后的状态, 考虑到可能存在跨轨道任务
                # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                eoi = state1[2]//orbit_period + 1    # 用当作结束时间计算卫星状态所在轨道
                next_state[bi, 0] = eoi
                next_state[bi, 1:5] = state1
                if eoi == soi:
                    next_state[bi, 5] = rest_memory - con_memory
                    next_state[bi, 6] = rest_energy - con_energy_t - con_energy_o
                else:
                    next_state[bi, 5] = sat_args.memory
                    next_state[bi, 6] = sat_args.energy
                # 3.2.3 更新当前任务的状态,并粗筛
                mask_ud[bi, ti] = 1  # 当前选中的任务
                curr_tasks = curr_tasks[curr_tasks.ne(ti)]  # 删除被选中的任务后剩余当前待规划任务
                for dti in curr_tasks:  # 去掉选择的任务后的当前待规划的任务逐个判断
                    if b_vtw[bi, dti, b_nw[bi, dti] - 1, 5] < state1[1]:  # 直接判断最后一个窗口最晚开始时间是否早于动作结束时间
                        mask_ud[bi, dti] = -1  # 舍弃
                        record_index[bi].append(dti)  # 放弃的任务
                break
        #  至此,成功规划了一个任务或者所有任务都无法成功规划
        # 3.3 没有找到合适的任务
        if not flag_complete_task:
            # 3.3 执行不成功, 对应矩阵mask_ud,不更新单步调度方案、状态,会继续选择下一个任务
            # 3.3.1 卫星状态
            # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            next_state[bi, :] = current_state[bi, :]  # 保持不变
            mask_ud[bi, ti] = -1  # 舍弃
            record_index[bi].append(ti)  # 放弃的任务
    return select_index, record_index, scheduling_results, next_state, mask_ud


# individual_step_scheduler(ct_list, matrix_n[比,:,:], state[bi, :], vtw_info[bi, :, :, :], require_info[bi, :, 2:], vtw_num[bi, :], sat_args)
# 一个解的一次解码中的调度调度器
def individual_step_scheduler(ct_list, matrix_n, current_state, vtw_info, require_info, nw_info, sat_args):
    """

    :param ct_list: list, 候选任务集合
    :param matrix_n: tensor, sl, mnw   表示任务的窗口状态
    :param current_state: 列表 6,    当前的状态   # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    :param vtw_info: tenor seq_len,max_nw,9  窗口信息 [0任务编号，1卫星编号，2轨道编号，3窗口编号，4开始时间，5结束时间，6斜率k，7截距b，8滚动角]
    :param require_info: sl, 2     需求信息    持续时间，优先级
    :param nw_info: 任务的窗口数量 `#b_index: tensor seq_len,
    :param sat_args: 卫星属性参数
    :return:  单步规划结果，更新后的卫星状态,更新后的mask_ud
    """
    # 1.初始值
    sl, mnw, _ = vtw_info.size()
    reo = sat_args.eco_rate
    ret = sat_args.ect_rate
    rm = sat_args.mc_rate
    orbit_period = sat_args.orbit_period    # 轨道周期
    state0 = current_state[1:5]
    # 2.初始化返回值
    next_state = torch.zeros(7)  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
    scheduling_results = torch.zeros(8)
    # 0选择的动作即任务，1是否能执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7收益
    select_index = -1
    delete_index = []  # 每个样本被舍弃的任务
    # 3.实现单步规划
    flag_complete_task = False
    for ti in ct_list:
        # 逐个任务判断是否能成功执行
        w_list = torch.where(matrix_n[ti, :])[0].tolist()  # 找出真值索引,即窗口编号
        for wi in w_list:
            # 3.1.1 判断可行性及生成观测动作
            # (1)先计算能否生成新动作，姿态转换时间是否满足
            is_done, state1 = calculate_ost(state0, vtw_info[ti, wi, 4:].tolist(),
                                            require_info[ti, 0].tolist())
            # 备注calculate_ost(oa0, vtw_info, d):
            # oa0:表示执行上一个任务的动作 [st,et,pa,ra]
            #                               0   1  2  3
            # vtw_info：窗口信息: 最早开始时间，最晚开始时间，k，b，滚动角
            #                       0               1         2  3    4
            # d：表示任务持续时间 # b_require[bi, task_id, 2]持续时间
            #  b_vtw:4开始时间，5结束时间，6最大俯仰角， 7最小俯仰角，8斜率k，9截距b，10滚动角
            if not is_done:  # 该动作没有成功生成
                continue  # 不满足条件就判断下一个窗口
            # state1 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            # 分两大类进行讨论
            soi = state1[1] // orbit_period + 1  # 轨道编号从1开始
            if soi == current_state[0]:  # 还在同一个轨道
                rest_memory = current_state[5]  # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
                rest_energy = current_state[6]
            else:  # 不在同一个轨道
                rest_memory = sat_args.memory
                rest_energy = sat_args.energy

            # （2） 存储和能量约束判断计算观测所需的内存和能量,并判断观测内存可行性
            con_memory = require_info[ti, 1] * rm
            con_energy_o = require_info[ti, 1] * reo  # 观测所需的能量
            if con_memory > rest_memory:  # 所需大于剩余
                # 如果刚进入一个新轨道，那么这两个条件必然是满足的
                # print('2 存储不满足约束', con_memory, rest_memory)
                continue  # 不满足条件就判断下一个窗口

            # （3）继续判断动作转换是否满足能量约束
            con_energy_t = (abs(state0[2] - state1[2]) + abs(state0[3] - state1[3])) * ret  # 以度数来计算
            if con_energy_t + con_energy_o > rest_energy:
                # print('3 能量不满足约束', con_energy_t + con_energy_o, rest_energy)
                continue  # 不满足条件就判断下一个任务
            flag_complete_task = True  # 成功规划的任务
            select_index = ti
            wi_selected = wi
            break  # 选中了一个可行窗口,中断循环
        if flag_complete_task:
            break
        # 至此完成了当前任务的可行窗口选择,两种情况:选中了一个窗口并成功规划,或没有成功规划

    if flag_complete_task:  # 执行成功
        # 3.2  任务成功执行更新单步调度方案,卫星执行完任务后的状态,对应矩阵mask_ud
        # 3.2.1  单步调度方案，根据开始时间定所在轨道
        # 0 任务编号，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角
        scheduling_results[0] = select_index  # 任务编号
        scheduling_results[1] = 1  # 成功执行
        scheduling_results[2] = soi  # 表示规划所在轨道，跨轨窗口其值可能不等于轨道编号
        scheduling_results[3: 7] = torch.tensor(state1)  # [st,et,pa,ra]
        scheduling_results[7] = require_info[select_index, 1]  # 收益
        # 3.2.2 执行完任务后的状态, 考虑到可能存在跨轨道任务
        # 0所在轨道，1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        eoi = state1[2] // orbit_period + 1  # 用当作结束时间计算卫星状态所在轨道
        next_state[0] = eoi
        next_state[1:5] = torch.tensor(state1)
        if eoi == soi:
            next_state[5] = rest_memory - con_memory
            next_state[6] = rest_energy - con_energy_t - con_energy_o
        else:
            next_state[5] = sat_args.memory
            next_state[6] = sat_args.energy
        # 3.2.3 粗筛
        ct_list.remove(select_index) # 删除被选中的任务后剩余当前待规划任务
        for dti in ct_list:  # 去掉选择的任务后的当前待规划的任务逐个判断
            if vtw_info[dti, nw_info[dti] - 1, 5] < state1[1]:  # 直接判断最后一个窗口最晚开始时间是否早于动作结束时间
                delete_index.append(dti)  # 放弃的任务
    # else:  # 未规划成功
    return flag_complete_task, scheduling_results, next_state, select_index, delete_index





