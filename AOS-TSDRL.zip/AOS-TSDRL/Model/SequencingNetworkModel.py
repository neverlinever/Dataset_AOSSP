# Description:
#   用于排序的网络模型，模型包括静态嵌入层、静态编码器、动态嵌入层、动态编码器和动态解码器
#   不要删除

# Programming date:2023-10-11
# Modification date:
# Programmer:LZ

import torch
from torch.utils.data import Dataset
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from Model.AttentionModel import FullAttention, ProbAttention, AttentionLayer, Attention
from Model.ProblemModel import scheduler_step

import matplotlib.pyplot as plt
import time
import datetime

import torch.optim as optim
import argparse


# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 有GPU就用
device = torch.device("cpu")  # 先用CPU算

# 0.规范训练数据由于预训练
class TrainDataset(Dataset):
    def __init__(self, var):
        super(TrainDataset, self).__init__()
        self.data_require, self.data_vtw, self.data_nw, self.data_mo, self.norm_require, self.norm_vtw, self.profit_rate = var
        self.size = self.data_require.size(0)  # 样本个数

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        # (static, dynamic, start_loc)
        return self.data_require[idx], self.data_vtw[idx], self.data_nw[idx], self.data_mo[idx], \
               self.norm_require[idx], self.norm_vtw[idx], self.profit_rate[idx]


# 1 Static embedding layer
class StaticEmbedding(nn.Module):
    def __init__(self, dim_r, dim_w, dim_ho, dim_o, dp):
        super(StaticEmbedding, self).__init__()
        self.dim_ho = dim_ho
        self.se_r = nn.Conv1d(dim_r, dim_ho, kernel_size=1)  # 输入（batch, channel, seq）
        self.se_w = nn.LSTM(dim_w, dim_ho, batch_first=True)  # 输入(batch, seq, feature)
        self.se_rw = nn.Conv1d(dim_o, dim_o, kernel_size=1)  # 输入出（batch, channel, seq）
        self.dropout = nn.Dropout(dp)

    def forward(self, xr, xw, xnw):
        """

        :param xr: tensor, (batch_size,tar_num,feature=dim_r=2), 归一化后的需求数据
        :param xw: tensor, (batch_size,tar_num,max_nw,feature=dim_w=9),归一化且补零后的窗口数据
        :param xnw: tensor, (batch,tar_num), 实际的窗口数量
        :return: out: tensor, （batch, tar_num, feature=dim_o=128）, 输出嵌入层结果
        """
        bs, sl, mnw, fw = xw.size()
        # se 1: 需求数据的嵌入
        br = F.relu(self.se_r(xr.transpose(1, 2)).transpose(1, 2))  # 输入(batch, hidden, seq) 输出(batch, seq, hidden)
        # se 2: 窗口数据的嵌入，效果与AOS-DRL-202304中的嵌入层完全一样
        tbs = bs * sl
        tbw = xw.reshape(tbs, mnw, fw)  # (tbs,mnw,feature)
        tnw = xnw.reshape(tbs)  # (tbs, )
        pack_tbw = pack_padded_sequence(tbw, tnw, batch_first=True, enforce_sorted=False)  # batch first, not sort
        _, (ht, _) = self.se_w(pack_tbw)
        bw = ht.squeeze().reshape(bs, sl, self.dim_ho)
        # se 3: 拼接后处理
        out = torch.cat((br, bw), 2)  # (batch, seq, 2*ho)
        out = self.dropout(self.se_rw(out.transpose(1, 2)).transpose(1, 2))  # in & out:(batch, seq, h)
        return out

# 2 Static encoder 利用ProbSparse Attention构建静态编码器
class StaticEncoder(nn.Module):
    def __init__(self, attn_str, d_model=128, factor=5, n_heads=8, d_ff=512,
                 dropout=0.1, activation='gelu', output_attention=False):
        super(StaticEncoder, self).__init__()
        attn = ProbAttention if attn_str == 'prob' else FullAttention
        self.attention = AttentionLayer(
            attn(False, factor, attention_dropout=dropout, output_attention=output_attention),
            d_model, n_heads, mix=False)
        self.conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_ff, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=d_ff, out_channels=d_model, kernel_size=1)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x, attn_mask=None):
        new_x, attn = self.attention(x, x, x, attn_mask=attn_mask)
        x = x + self.dropout(new_x)

        y = x = self.norm1(x)
        y = self.dropout(self.activation(self.conv1(y.transpose(-1, 1))))
        y = self.dropout(self.conv2(y).transpose(-1, 1))

        return self.norm2(x + y)


# 3 Dynamic decoder
class DynamicDecoder(nn.Module):
    def __init__(self, dim_rw, dim_s, dim_o, dp):
        super(DynamicDecoder, self).__init__()
        # 用简单的多层全连接网络实现对状态数据的升维与特征提取
        dim_sh = int(dim_rw/2)
        self.state_encoder1 = nn.Linear(dim_s, dim_sh)  # 输入出（seq,）用于对状态数据升维
        self.state_encoder2 = nn.Linear(dim_sh, dim_rw)
        self.state_encoder3 = nn.Linear(dim_rw, dim_rw)

        dim_in = dim_rw * 2
        self.linear = nn.Linear(dim_in, dim_o)  # 输入出（batch, channel, seq）
        self.hidden_dim = dim_o
        self.lstm = nn.LSTMCell(dim_o, dim_o)
        self.dropout = nn.Dropout(dp)
        self.sel_att = Attention(dim_o, dim_o)

    def forward(self, enc_rw, problem_info):

        # Decoder step1: 参数的初始化
        bs = enc_rw.size(0)
        sl = enc_rw.size(1)  # 序列长度即任务数
        sat_args, require_info, vtw_info, vtw_num, matrix_orbit = problem_info

        flag_task = torch.zeros([bs, sl], dtype=int)
        # 全0，表示未规划的任务，放弃用-1表示和已规划用1表示# 矩阵的索引就表示可选的任务索引
        flag_next = torch.zeros(bs, sl, dtype=int) - 1  # 初始化为-1,表示是否是下一阶段的待规划任务,
        # -1表示不是，0表示在第一个轨道，1表示在第二个轨道，2表示两个轨道都有
        task_key = torch.zeros([bs, sl, 2, 2], dtype=int)  # 任务检索表，用于存入该任务被安排在哪个轨道上和对应的窗口编号
        # 0初始的实际轨道就是窗口所在轨道, 1对应的窗口

        orbits = vtw_info[:, :, :, 2].reshape(bs, -1).int()  # 表示batch中 每个任务所有窗口所在的轨道编号(bs,sl*max_nw)
        # ，轨道编号从1开始，0不是轨道编号,可能有重复的
        orbits_list = [[] for _ in range(bs)]
        orbit_scheduled = [[] for _ in range(bs)]  # 因为初始化时不存在删除的任务
        for bi in range(bs):
            # 获取每个样本的轨道编号
            temp_orbits = torch.unique(
                orbits[bi, :])  # 默认sorted=True, return_inverse=False, return_counts=False, dim=None
            # 返回值升序排列，不返回重复元素的索引和个数
            if temp_orbits[0] == 0:
                temp_orbits = temp_orbits[1:]
            orbits_list[bi] = temp_orbits  # 每个样本中有任务的轨道
            orbit_scheduled[bi] = temp_orbits[:2]  # 取前两个轨道，如果轨道数小于2就只能取一个
            count_oi = 0
            for oi in temp_orbits[:2]:  # 取前两个轨道上的任务，有一种可能，轨道数量小于2
                t_tensor = torch.where(matrix_orbit[bi, :, oi, 0] == 1)[0]  # 在该轨道上的任务编号
                task_key[bi, t_tensor, count_oi, 0] = int(oi)  # 初始的实际轨道就是窗口所在轨道
                task_key[bi, t_tensor, count_oi, 1] = matrix_orbit[bi, t_tensor, oi, 1]
                count_oi += 1
                flag_next[bi, t_tensor] += count_oi
        # 完成了orbits_list有窗口的轨道的序列以及mask_next的构造
        state = torch.tensor([1, 0, 0, 0, 0, sat_args.memory, sat_args.energy]).repeat(bs, 1)  # 初始状态
        # 0所在轨道（初始为1，表示初始轨道），1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量

        mask_samples = torch.ones(bs).bool()  # 还需要规划的样本是true,其余False #  初始化全真
        ht = torch.zeros([bs, self.hidden_dim])
        ct = torch.zeros([bs, self.hidden_dim])
        results = [[] for _ in range(bs)]  # 每个调度步的结果，结果有8个特征，索引0表示选择的动作
        # 0选择的动作[0,sl)，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7任务收益
        results_evaluation = torch.zeros([bs, 6])  # 6个指标
        # 评价指标：总任务数，完成任务数，任务完成率，总收益，完成收益，任务收益率
        results_evaluation[:, 0] = sl
        results_evaluation[:, 3] = torch.sum(require_info[:, :, 3], 1)
        results_prob = torch.zeros([bs, sl])  # 每个动作被选中时的概率

        self.sel_att.init_inf(flag_next.size())
        x_rw = enc_rw.new_zeros(torch.Size((bs, enc_rw.size(2))))  # new_zeros会复制数据类型和所在设备等
        # Decoder step2: 开始循环计算概率获取序列
        while torch.any(mask_samples):  # 有真为真
            # Decoder step2.1: 动态信息归一化后，嵌入、编码
            # state:# 0所在轨道（初始为0，表示初始状态），1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
            # state_norm:# 0轨道编号，1空闲开始时间，2俯仰角，3侧摆角，4存储，5能量
            state_norm = torch.zeros(bs, 6)
            # 归一化处理
            state_norm[:, 0] = torch.true_divide(state[:, 0], sat_args.orbit_times)
            state_norm[:, 1] = torch.true_divide(state[:, 2], sat_args.period)
            state_norm[:, 2] = torch.true_divide((state[:, 3] - sat_args.min_pitch),
                                                 (sat_args.max_pitch - sat_args.min_pitch))
            state_norm[:, 3] = torch.true_divide((state[:, 4] - sat_args.min_roll),
                                                 (sat_args.max_roll - sat_args.min_roll))
            state_norm[:, 4] = torch.true_divide(state[:, 5], sat_args.memory)
            state_norm[:, 5] = torch.true_divide(state[:, 6], sat_args.energy)
            # 0轨道编号，1空闲开始时间，2俯仰角，3侧摆角，4存储，5能量
            # Decoder step2.2:  动态嵌入
            x_s = F.relu(self.state_encoder1(state_norm))
            x_s = F.relu(self.state_encoder2(x_s))
            x_s = self.state_encoder3(x_s)

            x_rws = torch.cat((x_rw, x_s), 1)
            x_rws = self.dropout(self.linear(x_rws))  # batch, 2*hidden
            ht, ct = self.lstm(x_rws, (ht, ct))     # ht用于计算概率

            hidden_t, probability = self.sel_att(ht, enc_rw, flag_next.eq(-1))  # 输入的mask中真值被屏蔽
            # probability 当前所有可选的所有概率

            select_ti = probability.argmax(1)
            mask_samples, step_select, step_delete, step_results, state, flag_task, flag_next, task_key \
                = scheduler_step(select_ti, mask_samples, flag_task, flag_next, state, vtw_info, require_info[:, :, 2:],
                                     vtw_num, matrix_orbit, sat_args, orbits_list, task_key)
            # 结果的汇总, 输入序列信息的更新, 更新策略矩阵
            x_rw = x_rw.new_zeros(x_rw.size())  # new_zeros会复制数据类型和所在设备等
            for bi in range(bs):
                results[bi].append(step_results[bi, :])
                if step_select[bi] != -1:
                    # 值为-1表示没有选中任何任务，当该样本早就结束才会这样
                    results_prob[bi, step_select[bi]] = probability[bi, step_select[bi]]
                    x_rw[bi, :] = enc_rw[bi, step_select[bi], :]
                    for ti in step_delete[bi]:
                        # 被放弃的任务的概率
                        results_prob[bi, ti] = probability[bi, ti]

        # Decoder step3: 计算指标以及选中动作的概率
        results_torch = torch.zeros([bs, len(results[0]), 8])
        for bi in range(bs):
            results_torch[bi, :, :] = torch.cat(results[bi]).view(len(results[0]), -1)
            # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
            results_evaluation[bi, 1] = torch.sum(results_torch[bi, :, 1])  # 能执行的任务数
            results_evaluation[bi, 2] = results_evaluation[bi, 1] / results_evaluation[bi, 0]
            results_evaluation[bi, 4] = (results_torch[bi, :, 1] * results_torch[bi, :, 7]).sum()
            results_evaluation[bi, 5] = results_evaluation[bi, 4] / results_evaluation[bi, 3]

        # results_evaluation
        return results_torch, results_evaluation, results_prob  # , consume_time

class NetModel(nn.Module):
    def __init__(self, dim_r, dim_w, dim_hrw, dim_s, dp=0.1, att_type='prob'):
        super(NetModel, self).__init__()
        dim_rw = dim_hrw * 2
        self.static_embedding = StaticEmbedding(dim_r, dim_w, dim_hrw, dim_rw, dp)
        self.static_encoder = StaticEncoder(att_type, dim_rw)
        # ( attn_str, d_model=512, factor=5, n_heads=8, d_ff=512, dropout=0.1, activation='gelu', output_attention=False)
        self.dynamic_decoder = DynamicDecoder(dim_rw, dim_s, dim_rw, dp)  # (dim_rw, dim_s, dim_o, dp)

    def forward(self, sa, br, bw, bn, bm, nr, nw):
        # sat_arg, batch_require, batch_vtw, batch_nw, batch_mo, batch_norm_require, batch_norm_vtw
        emb_rw = self.static_embedding(nr, nw, bn)
        xrw = self.static_encoder(emb_rw)
        problem_info = sa, br, bw, bn, bm
        Results, ResultsEvaluation, probs = self.dynamic_decoder(xrw, problem_info)
        return Results, ResultsEvaluation, probs
"""
class Critic(nn.Module):
    def __init__(self, dim_r, dim_w, dim_hrw, dim_s, dp=0.1, att_type='prob'):
        super(Critic, self).__init__()
        dim_rw = dim_hrw * 2
        self.static_embedding = StaticEmbedding(dim_r, dim_w, dim_hrw, dim_rw, dp)
        self.static_encoder = StaticEncoder(att_type)
        # (self, attn_str, factor=5, d_model=512, n_heads=8, d_ff=512, dropout=0.1, activation='gelu', output_attention=False)
"""



    # 用于测试的部分
if __name__ == "__main__":
    import torch
    import os

    # device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 有GPU就用
    device = torch.device("cpu")  # 先用CPU算

    # main 1：加载数据 以及 明确当前数据的保存路径
    # 1.1 加载数据
    data_type = True  # 真表示区域数据，假表示全球数据
    filepath0 = os.path.dirname(os.getcwd())  # 获取文件夹上一级的文件夹路径
    if data_type:
        # 训练数据包括 200，150，100，50 四种
        filepath1 = filepath0 + '\Data\FinalTraining_RD\FT_RD_'
        max_tar_num = 200
        num_sample_type = 4
    else:
        filepath1 = filepath0 + '\Data\FinalTraining_GD\FT_GD_'
        max_tar_num = 200
        num_sample_type = 4
    train_data = [[] for _ in range(num_sample_type)]

    tli = 0
    for num_tar in range(max_tar_num, 0, -50):
        path_name1 = filepath1 + str(num_tar) + '.pt'
        var_torch = torch.load(path_name1)  # torch_vtw, torch_nw, norm_data
        train_data[tli] = TrainDataset(var_torch)
        tli += 1

    task_num = 50
    if task_num == 200:
        di = 0
    elif task_num == 150:
        di = 1
    elif task_num == 100:
        di = 2
    elif task_num == 50:
        di = 3  # 其他情况都是3
    else:
        print('样本类型存在问题')

    train_data_sub = train_data[di]   # 0 200, 1 150, 2 100, 3 50
    # 1.2 保存路径
    algorithm_name = 'HADRL_ELR'
    time_str = '%s' % datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')
    now = time_str.replace('.', '')
    now = now.replace(' ', '_')
    now = now.replace(':', '')
    # path = filepath0 + '\\Result\\Training_Result\\RD_All\\' + algorithm_name + '_' + now
    path = filepath0 + '\\Result\\Training_Result\\RD_' + str(task_num) + '\\' + algorithm_name + '_' + now
    os.makedirs(path)
    fp = open(filepath0 + '\\Result\\Training_Result\\Training Log.txt', 'a', encoding='utf-8')
    fp.write('\n' + time_str + ' ' + algorithm_name + ' 训练结果保存路径：' + path)
    fp.close()
    print('\n训练结果保存路径：', path)
    path_writer = path + '\\log'
    writer = SummaryWriter(path_writer)

    # main 2: 参数设置
    # 2.1 卫星参数
    sat_parser = argparse.ArgumentParser(description='Parameters of AOS')
    sat_parser.add_argument('--orbit_times', default=14.20176543000019, type=float, help='24h内轨道圈次')
    sat_parser.add_argument('--orbit_period', default=24 * 60 * 60 / 14.20176543000019, type=float, help='平均轨道周期')
    sat_parser.add_argument('--energy', default=1500, type=float)
    sat_parser.add_argument('--memory', default=1000, type=float)
    sat_parser.add_argument('--eco_rate', default=1, type=float)  # 观测时能量消耗速率 *时间
    sat_parser.add_argument('--ect_rate', default=0.5, type=float)  # 姿态转换时能量消耗速率 *度数
    sat_parser.add_argument('--mc_rate', default=1, type=float)  # 内存消耗速率    *时间
    sat_parser.add_argument('--max_pitch', default=45, type=float)  # 最大俯仰角
    sat_parser.add_argument('--min_pitch', default=-45, type=float)  # 最小俯仰角
    sat_parser.add_argument('--max_roll', default=45, type=float)  # 最大滚动角
    sat_parser.add_argument('--min_roll', default=-45, type=float)  # 最小滚动角
    sat_parser.add_argument('--period', default=60 * 60 * 24, type=float)  # 调度周期
    SatArgs = sat_parser.parse_args()
    # 2.2 网络模型参数
    model_parser = argparse.ArgumentParser(description='Parameters of NetModel')
    # model_parser.add_argument('--max_nt', default=600, type=int, help='能处理的最大任务数')
    model_parser.add_argument('--dim_require', default=2, type=int, help='需求数据维度')
    model_parser.add_argument('--dim_vtw', default=4, type=int, help='窗口数据维度')
    model_parser.add_argument('--dim_half', default=128, type=int, help='静态嵌入隐藏层维度')
    model_parser.add_argument('--dim_state', default=6, type=int, help='动态嵌入维度')
    model_parser.add_argument('--drop_out', default=0.1, type=float, help='神经元停止概率')
    ModelArgs = model_parser.parse_args()
    # 2.3 训练参数
    train_parser = argparse.ArgumentParser(description='Parameters of training')
    train_parser.add_argument('--batch_size', default=128, type=int, help='批大小')
    train_parser.add_argument('--epochs', default=10, type=int, help='完整训练的轮次')
    train_parser.add_argument('--actor_lr', default=0.01, type=float, help='主网络学习率')
    train_parser.add_argument('--critic_lr', default=0.001, type=float, help='评估网络学习率')
    train_parser.add_argument('--max_grad_norm', default=5., type=float, help='网络参数梯度的范数上限')
    TrainArgs = train_parser.parse_args()
    # main 3: 构建网络以及训练算法-测试
    actor = NetModel(ModelArgs.dim_require, ModelArgs.dim_vtw, ModelArgs.dim_half, ModelArgs.dim_state,
                         ModelArgs.drop_out, 'prob')
    # dim_r, dim_w, dim_hrw, dim_s, dp=0.1, att_type='prob')
    actor_optim = optim.Adam(actor.parameters(), lr=TrainArgs.actor_lr)
    actor_scheduler = optim.lr_scheduler.ExponentialLR(actor_optim, gamma=0.99)
    actor.train()

    actor_losses, actor_rewards, actor_lr_list = [], [], []
    critic_losses, critic_rewards, critic_lr_list = [], [], []
    list_eval = []
    # main 4: 正式训练
    batch_size = 128
    count_times = 0
    start_time = time.time()
    for epoch in range(TrainArgs.epochs):
        train_loader = DataLoader(train_data_sub, batch_size, shuffle=True, drop_last=True)
        for batch_idx, batch in enumerate(train_loader):
            actor_lr = actor_optim.param_groups[0]['lr']
            batch_require, batch_vtw, batch_nw, batch_mo, batch_norm_require, batch_norm_vtw, target_reward = batch
            Results, ResultsEvaluation, probs = actor(SatArgs, batch_require, batch_vtw, batch_nw, batch_mo,
                                                      batch_norm_require, batch_norm_vtw)
            list_eval.append(ResultsEvaluation)
            reward = ResultsEvaluation[:, -1]
            logprob = torch.log(probs)
            if (logprob == float('-inf')).any():
                print('出现-inf', torch.where(logprob == float('-inf')))
                logprob[logprob == float('-inf')] = 0
            logprob = logprob.sum(1)  # 避免logprob全是0的情况
            advantage = reward - target_reward
            actor_loss = torch.mean(advantage.detach() * logprob)
            actor_optim.zero_grad()
            actor_loss.backward()
            torch.nn.utils.clip_grad_norm_(actor.parameters(), TrainArgs.max_grad_norm)
            actor_optim.step()
            # 数据保存并可视化
            # actor
            actor_reward = torch.mean(reward).item()
            actor_rewards.append(actor_reward)
            actor_losses.append(actor_loss.item())
            actor_lr_list.append(actor_lr)

            writer.add_scalar('actor\\actor_reward', actor_reward, count_times)
            writer.add_scalar('actor\\actor_loss', actor_loss, count_times)
            writer.add_scalar('actor\\actor_lr', actor_lr, count_times)

            actor_scheduler.step()
            count_times += 1

    writer.close()  # 关闭
    end_time = time.time()
    use_time = end_time - start_time

    # 画图
    # 1 actor的损失函数
    x1 = range(len(actor_losses))
    plt.figure(dpi=600, figsize=(16, 8))
    plt.subplot(3, 1, 1)
    plt.plot(x1, actor_losses, 'o-')
    plt.title('actor_loss')
    # 2 actor的收益值
    x2 = range(len(actor_rewards))
    plt.subplot(3, 1, 2)
    plt.plot(x2, actor_rewards, '.-')
    plt.title('actor_reward')
    # 3 actor学习率
    x3 = range(len(actor_lr_list))
    plt.subplot(3, 1, 3)
    plt.plot(x3, actor_lr_list, '.-')
    plt.title('actor_lr')

    plt_path = path + '\\RD_' + str(task_num) + '_' + now + '.png'
    plt.savefig(plt_path)
    plt.show()

    model_path = path + '\\NetModel_RD_' + str(task_num) + '_elr_' + now + '.pt'
    torch.save(actor.state_dict(), model_path)
    variable_path = path + '\\Result_RD_' + str(task_num) + '_elr_' + now + '.pt'
    torch.save((Results, list_eval, actor_rewards, actor_losses, actor_lr_list, use_time), variable_path)
    print('用时：', use_time)
    a_test = torch.load(variable_path)