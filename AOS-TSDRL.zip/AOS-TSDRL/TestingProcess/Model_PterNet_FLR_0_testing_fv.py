# Description: Testing for PN 去掉局部选择策略和粗筛策略
# 编写时间：2023-12-26
# 修改时间：
# 作者：LZ
#

import math
import numpy as np
import torch
import argparse
import torch.optim as optim
from torch import nn
import torch.nn.functional as F
from torch.nn import Parameter
from torch.utils.tensorboard import SummaryWriter

from torch.utils.data import DataLoader, Dataset
import matplotlib.pyplot as plt
import time
import datetime
import os
from copy import deepcopy

from Model.AttentionModel import Attention
from Model.Calculate_Observation_Action import calculate_ost


# 1.静态嵌入层
# 静态嵌入包括两部分，窗口数据和需求数据
class Embedding(nn.Module):
    def __init__(self, dim_in1, dim_in2, dim_half, dp):
        super(Embedding, self).__init__()
        self.dim_half = dim_half
        # self.emb_conv1d1 = nn.Conv1d(dim_in1, dim_half, kernel_size=1)   # 输入（batch, channel, seq）
        self.emb_lstm = nn.LSTM(dim_in1, dim_half, batch_first=True)     # 输入(batch, seq, feature), dropout=dp
        self.emb_conv1d2 = nn.Conv1d(dim_in2, dim_half, kernel_size=1)   # 输入出（batch, channel, seq）
        self.emb_conv1d3 = nn.Conv1d(dim_half * 2, dim_half * 2, kernel_size=1)   # 输入出（batch, channel, seq）
        self.layer_norm = nn.LayerNorm(dim_half * 2)
        self.dropout = nn.Dropout(dp)

    def forward(self, xw, xr, xnw):
        """

        :param xw: tensor, (batch_size,tar_num,max_nw,feature=4),归一化后的窗口数据
        :param xr: tensor, (batch_size,tar_num,feature=2), 归一化后的需求数据
        :param xnw: tensor, (batch,tar_num), 实际的窗口数量
        :return: out: tensor, （batch, tar_num, feature=128）, 输出嵌入层结果
        """
        bs, sl = xnw.size()
        # 1. 窗口数据嵌入
        bw = torch.zeros([bs, sl, self.dim_half])
        for bi in range(bs):
            max_nw = xnw[bi, :].max()
            for nw in range(1, max_nw+1):
                t_indexes = torch.where(xnw[bi, :] == nw)[0]
                mbw = xw[bi, t_indexes, :nw, :]  # (mini batch, num vtw, feature)
                # emb_mbw = F.relu(self.emb_conv1d1(mbw.transpose(1, 2)).transpose(1, 2))
                # 卷积的输入与输出都是（batch, feature,seq）,所以都转换了，输出为(mini batch, num vtw, feature)
                _, (h_t, _) = self.emb_lstm(mbw)  # h_t隐藏层最终输出，(mini batch,seq=nw, hidden)
                bw[bi, t_indexes, :] = h_t.squeeze()

        br = F.relu(self.emb_conv1d2(xr.transpose(1, 2)).transpose(1, 2))   # (batch, seq, hidden)
        bwr = self.emb_conv1d3(torch.cat((bw, br), 2).transpose(1, 2)).transpose(1, 2)   # (batch, seq, hidden)
        out = self.dropout(self.layer_norm(bwr))   # (batch, seq, hidden)
        return out      # batch, seq, feature


## 2. 静态编码器Encoder 部分包含：多头注意力层及后续的前馈神经网络
class Encoder(nn.Module):
    def __init__(self, din, dout):  #, dp
        super(Encoder, self).__init__()
        self.lstm = nn.LSTM(din, dout, batch_first=True)    # , dropout=dp
        # self.dropout = nn.Dropout(dp)

    def forward(self, enc_in):
        out, hc = self.lstm(enc_in)
        return out, hc


class Decoder(nn.Module):
    def __init__(self, enc_dim):
        """

        :param enc_dim: 编码器输出维度
        """
        super(Decoder, self).__init__()
        self.enc_dim = enc_dim
        self.hidden_dim = enc_dim
        # 动态信息嵌、编码，然后与静态信息整合
        # self.state_embedding = nn.Linear(state_dim, enc_dim)

        # 利用结合的信息计算概率
        self.lstm_cell = nn.LSTMCell(enc_dim, enc_dim)  # (batch, input_size)
        self.att = Attention(enc_dim, enc_dim)
        # self.layer_norm = nn.LayerNorm(enc_dim * 2)

    def forward(self, enc_out, hc):  #, problem_info, so_num
        """

        :param hc:
        :param enc_out: # batch,seq,feature

        :return:
        """
        # Decoder step1: 参数的初始化
        # 1.1 变量的初始化
        # sat_args, vtw_info, require_info, vtw_num, matrix_orbit = problem_info
        # matrix_orbit torch，（样本数，任务数，轨道数，2）# [表示任务是否在该轨道上，在的话是哪一个窗口]
        bs, sl, _ = enc_out.size()  # 序列长度即任务数
        h_t, c_t = hc
        h_t = h_t.squeeze()
        c_t = c_t.squeeze()

        # 1.2 中间值的初始化
        mask_undone = torch.zeros([bs, sl], dtype=int)
        # 全0，表示未规划的任务，已规划用1表示# 矩阵的索引就表示可选的任务索引
        # mask_samples = torch.ones(bs).bool()  # 还需要规划的样本是true,其余False #  初始化全真
        # state = torch.tensor([1, 0, 0, 0, 0, sat_args.memory, sat_args.energy]).repeat(bs, 1)  # 初始状态
        # 0所在轨道（初始为1，表示初始轨道），1开始时间，2结束时间，3俯仰角，4滚动角，5存储，6能量
        seq_input = enc_out.new_zeros(torch.Size((bs, self.enc_dim)))  # new_zeros会复制数据类型和所在设备等
        self.att.init_inf(mask_undone.size())

        # 需要找出有任务的轨道
        # orbits = vtw_info[:, :, :, 2].reshape(bs, -1).int()  # 表示batch中 每个任务所有窗口所在的轨道编号(bs,sl*max_nw)
        # # ，轨道编号从1开始，0不是轨道编号
        # orbits_list = [[] for _ in range(bs)]
        # orbit_current_index = torch.zeros(bs, dtype=int)  # 当前调度的轨道在orbits_list中的索引
        # for bi in range(bs):
        #     # 获取每个样本的有窗口的轨道编号
        #     temp_orbits = torch.unique(orbits[bi, :])   # 默认sorted=True, return_inverse=False, return_counts=False, dim=None
        #     # 返回值升序排列，不返回重复元素的索引和个数
        #     if temp_orbits[0] == 0:
        #         temp_orbits = temp_orbits[1:]
        #     orbits_list[bi] = temp_orbits   # 每个样本中有任务的轨道
        # 完成了orbits_list有窗口的轨道的序列

        # 1.3: 返回值初始化
        sort_tasks = torch.zeros([bs, sl], dtype=int)
        # results = [[] for _ in range(bs)]   # 每个调度步的结果，结果有8个特征，索引0表示选择的动作
        # # 0选择的动作[0,sl)，1是否能够执行，2所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7任务收益
        #
        # results_evaluation = torch.zeros([bs, 6])  # 6个指标
        # # 评价指标：总任务数，完成任务数，任务完成率，总收益，完成收益，任务收益率
        # results_evaluation[:, 0] = sl
        # results_evaluation[:, 3] = torch.sum(require_info[:, :, 1], 1)
        results_prob = torch.zeros([bs, sl])    # 每个动作被选中时的概率

        # Decoder step2: 开始循环计算概率获取序列
        for di in range(sl):  # 有真为真
            # 2.3.1：计算概率分布
            h_t, c_t = self.lstm_cell(seq_input, (h_t, c_t))
            if torch.isnan(h_t).any() or torch.isnan(c_t).any() or torch.isnan(seq_input).any():  #------测试-----------
                raise ValueError('Error-decoder: 2.2 exists NAN!')
            _, probability = self.att(h_t, enc_out, mask_undone.ne(0))  # 0表示未规划，把0值全部屏蔽
            # 2.3.2：选择下一个任务
            nt_tensor = probability.argmax(1)   # 每个样本的选出的任务编号
            sort_tasks[:, di] = deepcopy(nt_tensor)
            # 结果的汇总, 输入序列信息的更新, 更新策略矩阵
            seq_input = enc_out.new_zeros(seq_input.size())  # new_zeros会复制数据类型和所在设备等
            for bi in range(bs):
                seq_input[bi, :] = enc_out[bi, nt_tensor[bi], :]
                mask_undone[bi, nt_tensor[bi]] = 1
                results_prob[bi, nt_tensor[bi]] = probability[bi, nt_tensor[bi]]
        # # Decoder step3: 计算调度方案
        # results_torch = torch.zeros([bs, len(results[0]), 8])
        # for bi in range(bs):
        #     sat_action = torch.zeros()  # ost,oet,opa,ora,rm,re
        #     for ti in range(sl):
        #
        #
        #     results_torch[bi, :, :] = torch.cat(results[bi]).view(len(results[0]), -1)
        #     # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
        #     results_evaluation[bi, 1] = torch.sum(results_torch[bi, :, 1])  # 能执行的任务数
        #     results_evaluation[bi, 2] = results_evaluation[bi, 1]/results_evaluation[bi, 0]
        #     results_evaluation[bi, 4] = (results_torch[bi, :, 1] * results_torch[bi, :, 7]).sum()
        #     results_evaluation[bi, 5] = results_evaluation[bi, 4]/results_evaluation[bi, 3]

        # results_evaluation
        return sort_tasks, results_prob      # , consume_time


class PointerNet(nn.Module):
    def __init__(self, dw, dr, dh, dp):
        super(PointerNet, self).__init__()
        dhalf = dh//2
        self.embedding = Embedding(dw, dr, dhalf, dp)   # dim_in1, dim_in2, dim_half, dp
        self.encoder = Encoder(dh, dh)              # din, dout, #dp
        self.decoder = Decoder(dh)               # enc_dim, state_dim=6, dp=0.1, dp=dp

    def forward(self, bn, nr, nw): # sa, br, bw,  bm, , son
        emb_out = self.embedding(nw, nr, bn)
        if torch.isnan(emb_out).any():
            raise ValueError('Error0: nan exists in emb_out')
        enc_out, hc = self.encoder(emb_out)
        if torch.isnan(emb_out).any():
            raise ValueError('Error1: nan exists in enc_out')
        # problem_info = sa, bw, br, bn, bm
        # sat_args, vtw_info, require_info, vtw_num, matrix_orbit = problem_info
        task_seq, probs = self.decoder(enc_out, hc)    #, problem_info, son

        return task_seq, probs


class TestDataset(Dataset):
    def __init__(self, var):
        super(TestDataset, self).__init__()
        self.data_require, self.data_vtw, self.data_nw, self.data_mo, self.norm_require, self.norm_vtw = var
        # batch_require, batch_vtw, batch_nw, batch_mo, batch_norm_require, batch_norm_vtw
        self.size = self.data_require.size(0)  # 样本个数

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        # (static, dynamic, start_loc)
        return self.data_require[idx], self.data_vtw[idx], self.data_nw[idx], self.data_mo[idx], \
               self.norm_require[idx], self.norm_vtw[idx]


if __name__ == "__main__":

    # main 1：参数设置
    # 1.1 卫星参数
    sat_parser = argparse.ArgumentParser(description='Parameters of AOS')
    sat_parser.add_argument('--orbit_times', default=14.20176543000019, type=float, help='24h内轨道圈次')
    sat_parser.add_argument('--orbit_period', default=24 * 60 * 60 / 14.20176543000019, type=float, help='平均轨道周期')
    sat_parser.add_argument('--energy', default=1500, type=float)
    sat_parser.add_argument('--memory', default=1000, type=float)
    sat_parser.add_argument('--eco_rate', default=1, type=float)  # 观测时能量消耗速率 *时间
    sat_parser.add_argument('--ect_rate', default=0.5, type=float)  # 姿态转换时能量消耗速率 *度数
    sat_parser.add_argument('--mc_rate', default=1, type=float)  # 内存消耗速率    *时间
    sat_parser.add_argument('--max_pitch', default=45, type=float)  # 俯仰角
    sat_parser.add_argument('--min_pitch', default=-45, type=float)  # 俯仰角
    sat_parser.add_argument('--max_roll', default=45, type=float)  # 滚动角
    sat_parser.add_argument('--min_roll', default=-45, type=float)  # 滚动角
    sat_parser.add_argument('--period', default=60 * 60 * 24, type=float)  # 调度周期
    SatArgs = sat_parser.parse_args()
    # 1.2 网络模型参数
    model_parser = argparse.ArgumentParser(description='Parameters of NetModel')
    model_parser.add_argument('--max_nt', default=600, type=int, help='能处理的最大任务数')
    model_parser.add_argument('--dim_vtw', default=4, type=int, help='窗口数据维度')
    model_parser.add_argument('--dim_require', default=2, type=int, help='需求数据维度')
    model_parser.add_argument('--hidden_dim', default=128, type=int, help='隐藏层维度')
    model_parser.add_argument('--drop_out', default=0.1, type=float, help='神经元停止概率')
    ModelArgs = model_parser.parse_args()

    batch_size = 16
    sample_num = 128

    # main 2：加载模型
    filepath0 = os.path.dirname(os.getcwd())  # 获取文件夹上一级的文件夹路径
    algorithm_name = 'PN_FLR001'  # 算法名称
    # actor = PointerNet(ModelArgs.dim_vtw, ModelArgs.dim_require, ModelArgs.hidden_dim, ModelArgs.drop_out)
    actor = PointerNet(ModelArgs.dim_vtw, ModelArgs.dim_require, ModelArgs.hidden_dim, ModelArgs.drop_out)
    model_path = filepath0 + '\Model\Sequencing_Model\\' + algorithm_name + '.pt'
    state_dict = torch.load(model_path)
    actor.load_state_dict(state_dict)
    actor.eval()

    # 3.1 加载数据

    # 测试数据包括 50,100,150,200,250,300
    filepath1 = filepath0 + '\Data\FinalTesting_RD\FinalTesting_RD_'
    savepath1 = filepath0 + '\Result\Sequencing_TestingResult\\FinalTestingResult_' + algorithm_name + '_RD_'
    min_tar_num = 50
    max_tar_num = 300
    num_sample_type = 6

    for task_num in range(min_tar_num, max_tar_num + 1, min_tar_num):
        # main 3：加载数据 以及 明确当前数据的保存路径

        loadpath = filepath1 + str(task_num) + '.pt'
        var_torch = torch.load(loadpath)  # 载入测试数据
        test_result = var_torch[6]
        test_eval = var_torch[7]
        var_torch = var_torch[:6]
        test_data = TestDataset(var_torch)
        train_loader = DataLoader(test_data, batch_size, shuffle=False, drop_last=False)  # 不打乱样本顺序
        # torch_require, torch_vtw, torch_nw, matrix_orbit, norm_require, norm_vtw = test_data

        # 3.2 保存路径
        variable_path = savepath1 + str(task_num) + '.pt'
        time_str = '%s' % datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')
        fp = open(filepath0 + '\Result\Sequencing_TestingResult\Testing Log.txt', 'a', encoding='utf-8')
        fp.write('\n' + time_str + ' ' + algorithm_name + ' 测试结果保存路径：' + variable_path)
        fp.close()
        print('测试结果保存路径：', variable_path)

        # main 4: 正式测试
        Results = np.zeros([sample_num, task_num, 8])
        ResultsEvaluation = np.zeros([sample_num, 6])
        UseTime = 0

        for batch_idx, batch in enumerate(train_loader):
            # print(batch_idx)
            sbi = batch_idx * batch_size
            ebi = sbi + batch_size
            batch_require, batch_vtw, batch_nw, batch_mo, batch_norm_require, batch_norm_vtw = batch
            # batch_require = batch_require[:, :, 2:]
            start_time = time.time()

            task_sort, probs = actor(batch_nw, batch_norm_require, batch_norm_vtw)
            # 输入：sa, br, bw, bn, bm, nr, nw, sonSatArgs, batch_require, batch_vtw, batch_mo, , ModelArgs.scheduled_orbit_num
            # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
            # 根据任务的排序生成调度方案
            task_sort = task_sort.numpy()
            results = np.zeros([batch_size, task_num, 8])
            # 0选择的任务，1是否能够执行，2当前所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7任务收益
            result_eval = np.zeros([batch_size, 6])
            # 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
            result_eval[:, 0] = task_num
            result_eval[:, 3] = batch_require[:, :, 3].sum(1).numpy()
            for bi in range(batch_size):
                sat_action = np.zeros(7)  # 0oi,1ost,2oet,3opa,4ora,5rm,6re
                for ti in range(task_num):
                    task_id = task_sort[bi, ti]
                    flag_done = False
                    for wi in range(batch_nw[bi, task_id]):
                        vtw = batch_vtw[bi, task_id, wi, :].tolist()
                        # [0任务编号，1卫星编号，2轨道编号，3窗口编号，4开始时间，5结束时间，6斜率k，7截距b，8滚动角]
                        if vtw[5] < sat_action[2]:  # 最晚开始时间<空闲开始时间
                            continue
                        # 计算满足约束的最早观测动作
                        # False, oa0 = calculate_ost(oa0, vtw_info, d)
                        # oa0: 表示执行上一个任务的动作[st, et, pa, ra]
                        # vtw_info：窗口信息 最早开始时间，最晚开始时间，k，b，滚动角
                        # d：表示任务持续时间
                        # 输出 是否成功，下一个oa
                        flag_done, oa = calculate_ost(sat_action[1:5], vtw[4:], batch_require[bi, task_id, 2].tolist())
                        if flag_done:   # 生成了满足转换时间约束的窗口了
                            # 判断内存约束和能量约束
                            if vtw[2] == sat_action[0]:
                                rest_memory = sat_action[5]
                                rest_energy = sat_action[6]
                            else:
                                rest_memory = SatArgs.memory
                                rest_energy =SatArgs.energy
                            con_memory = SatArgs.mc_rate * batch_require[bi, task_id, 2]
                            con_energy = SatArgs.eco_rate * batch_require[bi, task_id, 2] + \
                                         SatArgs.ect_rate * (abs(oa[2]-sat_action[3]) + abs(oa[3]-sat_action[4]))
                            if con_memory>rest_memory or con_energy>rest_energy:
                                flag_done = False
                                continue
                            else:   # 满足约束# 更新卫星动作
                                sat_action[0] = vtw[2]  # 轨道
                                sat_action[1:5] = oa
                                sat_action[5] = rest_memory - con_memory
                                sat_action[6] = rest_energy - con_energy
                            break
                    # 至此，一个任务的调度完成
                    # 0选择的任务，1是否能够执行，2当前所在轨道，3开始时间，4结束时间，5俯仰角，6滚动角，7任务收益
                    results[bi, ti, 0] = task_id
                    results[bi, ti, 7] = batch_require[bi, task_id, 3].tolist()
                    if flag_done:
                        results[bi, ti, 1] = 1
                        results[bi, ti, 2:7] = sat_action[:5]
                # 至此，一个样本的任务调度完成
            # 至此，一个batch的调度完成
            # 计算调度指标# 评价指标：0总任务数，1完成任务数，2任务完成率，3总收益，4完成收益，5任务收益率
            result_eval[:, 1] = results[:, :, 1].sum(1)
            result_eval[:, 2] = result_eval[:, 1]/task_num
            result_eval[:, 4] = (results[:, :, 1] * results[:, :, 7]).sum(1)
            result_eval[:, 5] = result_eval[:, 4]/result_eval[:, 3]

            end_time = time.time()
            UseTime += end_time - start_time

            Results[sbi: ebi, :, :] = deepcopy(results)
            ResultsEvaluation[sbi: ebi, :] = deepcopy(result_eval)
        UseTime = UseTime / sample_num
        variable_path = savepath1 + str(task_num) + '.pt'
        # torch.save((Results, ResultsEvaluation, UseTime), variable_path)
        print('平均用时：', UseTime, variable_path)
